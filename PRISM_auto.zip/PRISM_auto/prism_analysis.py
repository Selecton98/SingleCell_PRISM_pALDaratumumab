#!/usr/bin/env python3
"""
PRISM single-cell analysis launcher (main entrypoint)

This script is the orchestration layer that:
  1) Validates inputs (h5ad + metadata CSV)
  2) Creates a task-scoped output directory structure
  3) Runs the PRISM pipeline either via `prism_analysis.py


Meta data
1) orig.ident
2) cytogenetics
3) outcome
4) treatment

Pipeline steps (as provided):
        ("1",   "R",  "standardpipeline_ver2.R"), [done]
        ("2.1", "PY", "starCAT_plasmacells.py"), [done]
        ("2.2", "R",  "plasmacell_ver3.R"), [done]
        ("3.1", "R",  "hematopiesis_TME_singleR.R") [done],
        ("3.2", "R",  "BM_TME_azimuth_myeloid.R"), [done]
        ("3.3", "PY", "BM_TME_starCAT_Tcells.py"), [done]
        ("3.4", "R",  "BM_TME_Bcells.R"),[done]
        ("3.5", "R",  "BM_TME_NKcells.R"),[done]
        ("4", "R",  "cellchat_78samples_trial3.R"),[done]

Single mode:
  - Always run full process by default in layered manner:
      1 -> 2.x -> 3.x -> 4.x
  - Write percent progress + status.json for UI polling
  - Log stdout/stderr per step into output_dir/logs/

Usage:
python prism_main.py --task-id 1 \
  --h5ad input.h5ad --metadata meta.csv \
  --output-dir out/task_1 --scripts-dir /path/to/scripts 

Author: Xuezhu Sunny Wang
"""

import argparse
import json
import os
import sys
import time
import shutil
import traceback
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# UI / Status helpers
# ----------------------------

def print_prism() -> None:
    lines = [
        "████  ████  █████ █████ █   █",
        "█   █ █   █   █   █     ██ ██",
        "████  ████    █   █████ █ █ █",
        "█     █  █    █       █ █   █",
        "█     █   █ █████ █████ █   █",
    ]
    print("\n".join(lines))


def update_task_status(
    task_id: int,
    status: str,
    progress: int = 0,
    message: Optional[str] = None,
    error: Optional[str] = None,
    status_path: Optional[Path] = None,
) -> None:
    """
    Print status and optionally write a status JSON file in output_dir for UI polling.

    status: e.g. "queued" | "processing" | "completed" | "failed"
    progress: 0-100
    message: short human-readable message
    """
    payload: Dict[str, Any] = {
        "task_id": task_id,
        "status": status,
        "progress": int(progress),
        "ts": int(time.time()),
    }
    if message:
        payload["message"] = message
    if error:
        payload["error"] = error

    line = f"[Task {task_id}] {status} {progress}%"
    if message:
        line += f" | {message}"
    print(line, flush=True)

    if error:
        print(f"[Task {task_id}] ERROR: {error}", file=sys.stderr, flush=True)

    if status_path is not None:
        try:
            status_path.parent.mkdir(parents=True, exist_ok=True)
            with status_path.open("w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
        except Exception:
            # Status writing should never crash the pipeline
            print(f"[Task {task_id}] Warning: failed to write status file: {status_path}", file=sys.stderr, flush=True)


def safe_json_loads(raw: str, default: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if default is None:
        default = {}
    if raw is None or raw.strip() == "":
        return dict(default)
    try:
        obj = json.loads(raw)
        if not isinstance(obj, dict):
            raise ValueError("params JSON must be an object/dict")
        return obj
    except Exception:
        return dict(default)


# ----------------------------
# Subprocess runner
# ----------------------------

@dataclass
class CmdResult:
    returncode: int
    stdout_path: Path
    stderr_path: Path
    duration_s: float


def run_cmd(
    cmd: List[str],
    cwd: Optional[Path],
    env: Optional[Dict[str, str]],
    stdout_path: Path,
    stderr_path: Path,
    timeout_s: Optional[int] = None,
    dry_run: bool = False,
) -> CmdResult:
    """
    Run a command, streaming stdout/stderr to files.
    """
    stdout_path.parent.mkdir(parents=True, exist_ok=True)
    stderr_path.parent.mkdir(parents=True, exist_ok=True)

    t0 = time.time()

    if dry_run:
        stdout_path.write_text("DRY RUN\n" + " ".join(cmd) + "\n", encoding="utf-8")
        stderr_path.write_text("", encoding="utf-8")
        return CmdResult(0, stdout_path, stderr_path, time.time() - t0)

    with stdout_path.open("w", encoding="utf-8") as out_f, stderr_path.open("w", encoding="utf-8") as err_f:
        proc = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd is not None else None,
            env=env,
            stdout=out_f,
            stderr=err_f,
            text=True,
            timeout=timeout_s,
            check=False,
        )

    return CmdResult(proc.returncode, stdout_path, stderr_path, time.time() - t0)


# ----------------------------
# PRISM pipeline plan (layered)
# ----------------------------

def layered_step_plan() -> List[Tuple[str, str, str, str]]:
    """
    Returns list of (layer, step_id, kind, script_filename)
      - layer: "1" | "2" | "3" | "4" (grouping for reporting)
      - kind:  "R" | "PY"
    """
    return [
        ("1", "1",   "R",  "standardpipeline_ver2.R"),

        ("2", "2.1", "PY", "starCAT_plasmacells.py"),
        ("2", "2.2", "R",  "plasmacell_ver3.R"),

        ("3", "3.1", "R",  "hematopiesis_TME_singleR.R"),
        ("3", "3.2", "R",  "BM_TME_azimuth_myeloid.R"),
        ("3", "3.3", "PY", "BM_TME_starCAT_Tcells.py"),
        ("3", "3.4", "R",  "BM_TME_Bcells.R"),
        ("3", "3.5", "R",  "BM_TME_NKcells.R"),

        ("4", "4", "R",  "cellchat_78samples_trial3.R"),
    ]


def ensure_file_exists(p: Path, label: str) -> None:
    if not p.exists():
        raise FileNotFoundError(f"{label} not found: {p}")
    if p.is_dir():
        raise IsADirectoryError(f"{label} is a directory, expected a file: {p}")


def maybe_copy_inputs(h5ad: Path, meta: Path, workdir: Path, prefer_symlink: bool = True) -> Tuple[Path, Path]:
    """
    Copy (or symlink) inputs into output_dir/work to standardize downstream access.
      work/input.h5ad
      work/metadata.csv
    """
    workdir.mkdir(parents=True, exist_ok=True)
    h5ad_dst = workdir / "input.h5ad"
    meta_dst = workdir / "metadata.csv"

    def _place(src: Path, dst: Path) -> None:
        if dst.exists():
            dst.unlink()
        if prefer_symlink:
            try:
                os.symlink(src.resolve(), dst)
                return
            except Exception:
                pass
        shutil.copy2(src, dst)

    _place(h5ad, h5ad_dst)
    _place(meta, meta_dst)
    return h5ad_dst, meta_dst


def progress_for_step_index(step_idx_zero_based: int, total_steps: int) -> int:
    """
    Map step index -> progress percentage (smooth monotonic).
    Reserves:
      0-5   : queued/initialization
      5-95  : step execution
      95-100: wrap-up
    """
    if total_steps <= 0:
        return 95
    start, end = 5, 95
    frac = step_idx_zero_based / total_steps
    return int(round(start + frac * (end - start)))


def run_full_pipeline(
    task_id: int,
    h5ad_path: Path,
    meta_path: Path,
    output_dir: Path,
    scripts_dir: Path,
    params: Dict[str, Any],
    rscript_bin: str,
    python_bin: str,
    dry_run: bool,
    status_path: Path,
) -> bool:
    """
    Run PRISM full pipeline in layered manner (1 -> 2.x -> 3.x -> 4.x),
    with status/progress + per-step logs.
    """
    # Directories
    logs_dir = output_dir / "logs"
    work_dir = output_dir / "work"
    artifacts_dir = output_dir / "artifacts"
    logs_dir.mkdir(parents=True, exist_ok=True)
    work_dir.mkdir(parents=True, exist_ok=True)
    artifacts_dir.mkdir(parents=True, exist_ok=True)

    # Standardize inputs into work/
    h5ad_local, meta_local = maybe_copy_inputs(h5ad_path, meta_path, work_dir, prefer_symlink=True)

    # Environment overrides (optional)
    env = os.environ.copy()
    if isinstance(params.get("env"), dict):
        env.update({k: str(v) for k, v in params["env"].items()})

    # Per-step extra args (optional)
    step_args_map = params.get("step_args", {})
    if step_args_map is None:
        step_args_map = {}
    if not isinstance(step_args_map, dict):
        step_args_map = {}

    # Whether to pass standard args to each step script
    pass_standard_args = params.get("pass_standard_args", True)

    # Timeout (optional)
    timeout_s = params.get("timeout_s", None)

    plan = layered_step_plan()
    total_steps = len(plan)

    # Layer boundaries for nicer messages
    update_task_status(task_id, "processing", 5, message="Initializing pipeline", status_path=status_path)

    for idx, (layer, step_id, kind, script_name) in enumerate(plan):
        # Progress BEFORE starting this step
        prog = progress_for_step_index(idx, total_steps)
        update_task_status(
            task_id,
            "processing",
            prog,
            message=f"Layer {layer}: starting step {step_id} ({script_name})",
            status_path=status_path,
        )

        script_path = scripts_dir / script_name
        ensure_file_exists(script_path, f"Script for step {step_id}")

        standard_args: List[str] = []
        if pass_standard_args:
            standard_args = [
                "--h5ad", str(h5ad_local),
                "--metadata", str(meta_local),
                "--output-dir", str(output_dir),
                "--work-dir", str(work_dir),
                "--artifacts-dir", str(artifacts_dir),
                "--task-id", str(task_id),
                "--step-id", str(step_id),
            ]

        extra_args = step_args_map.get(step_id, [])
        if extra_args is None:
            extra_args = []
        if not isinstance(extra_args, list):
            raise ValueError(f'params["step_args"]["{step_id}"] must be a list of strings')

        if kind == "R":
            cmd = [rscript_bin, str(script_path)] + standard_args + [str(x) for x in extra_args]
        elif kind == "PY":
            cmd = [python_bin, str(script_path)] + standard_args + [str(x) for x in extra_args]
        else:
            raise ValueError(f"Unknown script kind: {kind}")

        stdout_path = logs_dir / f"step_{step_id.replace('.','_')}.stdout.log"
        stderr_path = logs_dir / f"step_{step_id.replace('.','_')}.stderr.log"

        # Run step (cwd is work_dir so scripts can use relative paths if needed)
        res = run_cmd(
            cmd=cmd,
            cwd=work_dir,
            env=env,
            stdout_path=stdout_path,
            stderr_path=stderr_path,
            timeout_s=timeout_s,
            dry_run=dry_run,
        )

        if res.returncode != 0:
            err_msg = (
                f"FAILED step {step_id} (layer {layer}) exit={res.returncode}. "
                f"See logs: {stderr_path} (stderr), {stdout_path} (stdout)"
            )
            update_task_status(task_id, "failed", prog, error=err_msg, status_path=status_path)
            return False

        # Progress AFTER completing this step
        prog_after = progress_for_step_index(idx + 1, total_steps)
        update_task_status(
            task_id,
            "processing",
            prog_after,
            message=f"Layer {layer}: completed step {step_id} in {res.duration_s:.1f}s",
            status_path=status_path,
        )

    return True


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="PRISM single-cell analysis (full pipeline, single mode)")
    parser.add_argument("--task-id", type=int, required=True, help="Analysis task ID")
    parser.add_argument("--h5ad", type=str, required=True, help="Input .h5ad file path")
    parser.add_argument("--metadata", type=str, required=True, help="Input metadata .csv file path")
    parser.add_argument("--output-dir", type=str, required=True, help="Output directory for results")
    parser.add_argument("--scripts-dir", type=str, required=True, help="Directory containing the PRISM step scripts")
    parser.add_argument("--params", type=str, default="{}", help="Additional parameters as JSON string")

    # R/Python runners
    parser.add_argument("--rscript", type=str, default="Rscript", help="Path to Rscript binary")
    parser.add_argument("--python", type=str, default=sys.executable, help="Path to Python interpreter to run step .py scripts")
    parser.add_argument("--dry-run", action="store_true", help="Do not execute commands; write what would run to logs")

    args = parser.parse_args()

    print_prism()

    output_dir = Path(args.output_dir).resolve()
    scripts_dir = Path(args.scripts_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    status_path = output_dir / "status.json"
    logs_dir = output_dir / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    params = safe_json_loads(args.params, default={})

    h5ad_path = Path(args.h5ad).expanduser().resolve()
    meta_path = Path(args.metadata).expanduser().resolve()

    # Validate inputs
    try:
        ensure_file_exists(h5ad_path, "h5ad input")
        ensure_file_exists(meta_path, "metadata CSV")
    except Exception as e:
        update_task_status(args.task_id, "failed", 0, error=str(e), status_path=status_path)
        sys.exit(1)

    # Run manifest for reproducibility
    manifest = {
        "task_id": args.task_id,
        "h5ad": str(h5ad_path),
        "metadata": str(meta_path),
        "scripts_dir": str(scripts_dir),
        "output_dir": str(output_dir),
        "rscript": args.rscript,
        "python": args.python,
        "dry_run": bool(args.dry_run),
        "params": params,
        "started_at_epoch": int(time.time()),
    }
    (output_dir / "run_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    update_task_status(args.task_id, "queued", 0, message="Queued", status_path=status_path)

    try:
        update_task_status(args.task_id, "processing", 2, message="Starting full PRISM pipeline", status_path=status_path)

        ok = run_full_pipeline(
            task_id=args.task_id,
            h5ad_path=h5ad_path,
            meta_path=meta_path,
            output_dir=output_dir,
            scripts_dir=scripts_dir,
            params=params,
            rscript_bin=args.rscript,
            python_bin=args.python,
            dry_run=args.dry_run,
            status_path=status_path,
        )

        if ok:
            update_task_status(args.task_id, "completed", 100, message="Pipeline completed successfully", status_path=status_path)
            sys.exit(0)
        else:
            update_task_status(args.task_id, "failed", 0, error="Pipeline returned failure", status_path=status_path)
            sys.exit(1)

    except Exception as e:
        tb = traceback.format_exc()
        (logs_dir / "fatal.traceback.txt").write_text(tb, encoding="utf-8")
        update_task_status(
            args.task_id,
            "failed",
            0,
            error=f"{e} (see logs/fatal.traceback.txt)",
            status_path=status_path,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()

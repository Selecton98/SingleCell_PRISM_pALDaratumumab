#!/usr/bin/env Rscript

# ============================
# PRISM standard CLI header (R) — PATCHED FULL SCRIPT (Myeloid)
# - Robust plotting to PDF folder
# - Safer Azimuth step (tryCatch)
# - Fix reduction naming consistency (use "umap")
# - Ensure all plots are saved
# - Create Annotation_myeloid by integrating final_label + UMAP_tag
# - Apply requested CD14Mono renaming strategy
# ============================

suppressPackageStartupMessages({
  library(optparse)
  library(Seurat)
  library(patchwork)
  library(ggplot2)
  library(scCustomize)

  # Azimuth
  library(Azimuth)

  # Data munging / plotting helpers
  library(dplyr)
  library(tidyr)
  library(purrr)
  library(reshape2)
  library(dendextend)
  library(ggdendro)
  library(viridis)
  library(pheatmap)
  library(hexbin)

  # Gene sets
  library(msigdbr)
  library(readr)
})

set.seed(123)

# ----------------------------
# CLI options
# ----------------------------
option_list <- list(
  make_option(c("--h5ad"), type="character", default=NA_character_,
              help="Path to input .h5ad (not used in this step unless you enable conversion)"),
  make_option(c("--metadata"), type="character", default=NA_character_,
              help="Path to metadata CSV (optional for this step unless you need it)"),
  make_option(c("--output-dir"), type="character", default=".",
              help="Task output directory (root for logs/work/artifacts)"),
  make_option(c("--work-dir"), type="character", default=NA_character_,
              help="Working directory for intermediates (default: <output-dir>/work)"),
  make_option(c("--artifacts-dir"), type="character", default=NA_character_,
              help="Directory for final artifacts (default: <output-dir>/artifacts)"),
  make_option(c("--task-id"), type="integer", default=NA_integer_,
              help="Task ID (for logging/UI)"),
  make_option(c("--step-id"), type="character", default=NA_character_,
              help="Step ID like 1, 2.1, 3.2, 4.1 (for logging/UI)"),

  # Inputs used in THIS script
  make_option(c("--seurat-rds"), type="character", default=NA_character_,
              help="Path to input Seurat .rds (default: <work-dir>/sce1_myeloidcell_lineage_Myeloid.rds)")
)

opt <- parse_args(OptionParser(option_list = option_list))

# ----------------------------
# Helpers: robust option
# ----------------------------
is_unset <- function(x) is.null(x) || length(x) == 0 || all(is.na(x)) || !nzchar(as.character(x)[1])
`%||%` <- function(a, b) if (!is_unset(a)) a else b

# ---- Logging helpers ----
log_msg <- function(...) {
  ts <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  cat(sprintf("[%s][task=%s][step=%s] ", ts, opt$task_id, opt$step_id),
      paste0(..., collapse=""), "\n")
}

# ---- Resolve defaults (ROBUST) ----
opt$output_dir    <- opt$output_dir %||% "."
opt$work_dir      <- opt$work_dir %||% file.path(opt$output_dir, "work")
opt$artifacts_dir <- opt$artifacts_dir %||% file.path(opt$output_dir, "artifacts")

dir.create(opt$output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$work_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$artifacts_dir, recursive = TRUE, showWarnings = FALSE)

work_path <- function(...) file.path(opt$work_dir, ...)
art_path  <- function(...) file.path(opt$artifacts_dir, ...)

# ---- File check helper ----
require_file <- function(path, label) {
  if (is_unset(path)) stop(sprintf("Missing required input: %s", label))
  if (!file.exists(path)) stop(sprintf("File not found for %s: %s", label, path))
}

# ---- Plot path helper ----
plots_dir <- file.path(opt$artifacts_dir, "plots_step3")
dir.create(plots_dir, recursive = TRUE, showWarnings = FALSE)

plot_pdf_path <- function(name) {
  safe <- gsub("[[:space:]]+", "_", name)
  safe <- gsub("[^A-Za-z0-9_\\-\\.]", "", safe)
  file.path(plots_dir, paste0(safe, ".pdf"))
}

# ---- Safe ggsave wrapper (cairo if available) ----
save_plot_pdf <- function(p, name, w=10, h=8) {
  out_pdf <- plot_pdf_path(name)
  device_fun <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(filename = out_pdf, plot = p, width = w, height = h, device = device_fun)
  log_msg("Saved plot: ", out_pdf)
  invisible(out_pdf)
}

# ---- Save base plots safely (for non-ggplot objects) ----
save_base_pdf <- function(expr, name, w=10, h=8) {
  out_pdf <- plot_pdf_path(name)
  if (capabilities("cairo")) {
    grDevices::cairo_pdf(out_pdf, width = w, height = h)
  } else {
    grDevices::pdf(out_pdf, width = w, height = h)
  }
  on.exit(grDevices::dev.off(), add = TRUE)
  tryCatch(force(expr), error = function(e) {
    log_msg("WARNING: base plot failed for ", name, " : ", conditionMessage(e))
  })
  log_msg("Saved plot: ", out_pdf)
  invisible(out_pdf)
}

# ----------------------------
# Start logs
# ----------------------------
log_msg("PRISM R step starting")
log_msg("h5ad: ", opt$h5ad)
log_msg("metadata: ", opt$metadata)
log_msg("output_dir: ", opt$output_dir)
log_msg("work_dir: ", opt$work_dir)
log_msg("artifacts_dir: ", opt$artifacts_dir)

# ----------------------------
# Inputs
# ----------------------------
seurat_rds <- opt$seurat_rds %||% work_path("sce1_nonplasmacell_lineage_Myeloid.rds")
require_file(seurat_rds, "Seurat RDS (--seurat-rds or <work-dir>/sce1_nonplasmacell_lineage_Myeloid.rds)")

log_msg("Loading Seurat object: ", seurat_rds)
sce1_myeloid <- readRDS(seurat_rds)
if (!inherits(sce1_myeloid, "Seurat")) stop("Loaded object is not a Seurat object: ", seurat_rds)

DefaultAssay(sce1_myeloid) <- "RNA"

# ----------------------------
# Standard analysis workflow
# ----------------------------
log_msg("NormalizeData / FindVariableFeatures")
sce1_myeloid <- NormalizeData(sce1_myeloid, verbose = FALSE)
sce1_myeloid <- FindVariableFeatures(sce1_myeloid, verbose = FALSE)

log_msg("ScaleData / RunPCA")
sce1_myeloid <- ScaleData(
  sce1_myeloid,
  features = VariableFeatures(sce1_myeloid),
  verbose = FALSE
)
sce1_myeloid <- RunPCA(
  sce1_myeloid,
  features = VariableFeatures(sce1_myeloid),
  verbose = FALSE
)

log_msg("FindNeighbors / FindClusters / RunUMAP")
sce1_myeloid <- FindNeighbors(sce1_myeloid, dims = 1:15, reduction = "pca", verbose = FALSE)
sce1_myeloid <- FindClusters(sce1_myeloid, resolution = 1, cluster.name = "seurat_clusters", verbose = FALSE)

# Use standard Seurat reduction name "umap" (lowercase) to avoid downstream confusion
sce1_myeloid <- RunUMAP(sce1_myeloid, dims = 1:15, reduction = "pca", reduction.name = "umap", verbose = FALSE)

# ----------------------------
# Plots (early-style) -> ALWAYS saved
# ----------------------------
p_umap_clusters <- DimPlot_scCustom(
  sce1_myeloid,
  pt.size = 1,
  reduction = "umap",
  group.by = "seurat_clusters",
  label = TRUE
)
save_plot_pdf(p_umap_clusters, "umap_seurat_clusters_myeloid", w=10, h=8)

if ("orig.ident" %in% colnames(sce1_myeloid@meta.data)) {
  p_umap_orig <- DimPlot_scCustom(
    sce1_myeloid,
    pt.size = 1,
    reduction = "umap",
    group.by = "orig.ident",
    label = TRUE
  )
  save_plot_pdf(p_umap_orig, "umap_orig_ident_myeloid", w=10, h=8)
} else {
  log_msg("Skipping orig.ident UMAP: orig.ident not found in meta.data.")
}

# ----------------------------
# Azimuth mapping (guarded)
# ----------------------------
bm_anno <- NULL
bm_anno <- tryCatch(
  {
    log_msg("Running Azimuth mapping (reference = bonemarrowref)")
    RunAzimuth(query = sce1_myeloid, reference = "bonemarrowref")
  },
  error = function(e) {
    log_msg("WARNING: RunAzimuth failed: ", conditionMessage(e))
    NULL
  }
)

if (is.null(bm_anno)) {
  log_msg("Azimuth unavailable; continuing with sce1_myeloid only. Saving object and exiting gracefully.")
  saveRDS(sce1_myeloid, work_path("sce1_myeloid_postqc_no_azimuth.rds"))
  log_msg("PRISM R step finished (no Azimuth).")
  quit(save = "no", status = 0)
}

# Save Azimuth UMAPs if present
if ("predicted.celltype.l2" %in% colnames(bm_anno@meta.data)) {
  p_ref <- tryCatch(DimPlot(bm_anno, reduction = "ref.umap", group.by = "predicted.celltype.l2", label = TRUE),
                    error = function(e) NULL)
  if (!is.null(p_ref)) save_plot_pdf(p_ref, "azimuth_ref_umap_predicted_celltype_l2", w=11, h=8)

  p_q <- tryCatch(DimPlot(bm_anno, reduction = "umap", group.by = "predicted.celltype.l2", label = TRUE),
                  error = function(e) NULL)
  if (!is.null(p_q)) save_plot_pdf(p_q, "azimuth_query_umap_predicted_celltype_l2", w=11, h=8)
}

# Flag low-confidence predictions (tunable)
if (all(c("predicted.celltype.l2.score","predicted.celltype.l2") %in% colnames(bm_anno@meta.data))) {
  bm_anno$low_conf <- bm_anno$predicted.celltype.l2.score < 0.5
  tab_low <- table(bm_anno$low_conf, useNA = "ifany")
  log_msg("Low-confidence table: ", paste(capture.output(print(tab_low)), collapse=" | "))

  # Keep only confident
  bm_anno <- subset(bm_anno, subset = predicted.celltype.l2.score >= 0.5)
} else {
  log_msg("WARNING: predicted.celltype.l2(.score) not found; skipping low-confidence filter.")
}

# ----------------------------
# Subset myeloid compartments by Azimuth labels (safe)
# ----------------------------
if (!("predicted.celltype.l2" %in% colnames(bm_anno@meta.data))) {
  stop("Azimuth output missing predicted.celltype.l2; cannot proceed with myeloid subsetting.")
}

Idents(bm_anno) <- "predicted.celltype.l2"

targets <- c(
  "ASDC","CD14 Mono","CD16 Mono","cDC2","cDC1","LMPP",
  "GMP","HSC","pDC","pre-mDC","pre-pDC","Macrophage"
)

available <- levels(Idents(bm_anno))
keep <- intersect(targets, available)
missing <- setdiff(targets, available)

if (length(keep) == 0) {
  stop(
    paste0(
      "None of the requested identities are present in Idents(bm_anno).\n",
      "Available identities:\n - ", paste(available, collapse = "\n - ")
    )
  )
}
if (length(missing) > 0) {
  log_msg("Requested identities NOT found and will be skipped: ", paste(missing, collapse = ", "))
}

bm_anno_myeloid <- subset(bm_anno, idents = keep)

# Plot myeloid Azimuth labels
p_myeloid_l2 <- DimPlot_scCustom(
  bm_anno_myeloid,
  pt.size = 0.5,
  reduction = "umap",
  group.by = "predicted.celltype.l2",
  label = TRUE
)
save_plot_pdf(p_myeloid_l2, "umap_myeloid_predicted_celltype_l2", w=11, h=8)

# ----------------------------
# Integrate Nover overrides into final_label (robust)
# ----------------------------
mlab <- as.character(bm_anno_myeloid$predicted.celltype.l2)
lab0 <- if ("Nover" %in% colnames(bm_anno_myeloid@meta.data)) as.character(bm_anno_myeloid$Nover) else rep(NA_character_, length(mlab))

final <- dplyr::case_when(
  !is.na(lab0) & lab0 == "Colony Forming Unit-Monocytes"     ~ "Colony Forming Unit-Monocytes",
  !is.na(lab0) & lab0 == "Colony Forming Unit-Granulocytes"  ~ "Colony Forming Unit-Granulocytes",
  !is.na(lab0) & lab0 == "Granulocytes (Neutrophils)"        ~ "Granulocytes (Neutrophils)",
  TRUE                                                       ~ mlab
)
final[is.na(final) | final == ""] <- lab0[is.na(final) | final == ""]

bm_anno_myeloid$final_label <- factor(final, levels = sort(unique(final)))

p_final_label <- DimPlot_scCustom(
  bm_anno_myeloid,
  pt.size = 0.5,
  reduction = "umap",
  group.by = "final_label",
  label = TRUE
)
save_plot_pdf(p_final_label, "umap_myeloid_final_label", w=12, h=8)

Idents(bm_anno_myeloid) <- "final_label"

# ----------------------------
# Marker DotPlot + clustered re-ordering (saved)
# ----------------------------
blue_red_palette <- colorRampPalette(c("steelblue", "white", "firebrick"))
cols_vec <- colorRampPalette(c("steelblue", "white", "firebrick"))(26)

allgene <- c(
  "CD34",
  "VCAN","THBS1","S1PR3","CD36","ALDH1A1","CYP1B1","NRG1",
  "CXCR1","CXCR2","FCGR3B","MME","PI3","G0S2",
  "MPO","ELANE","PRTN3","AZU1","CTSG","DEFA4","OLR1",
  "CEACAM8",
  "CDC20","UBE2C","BIRC5","CENPA",
  "CD14","CD163","CLEC10A","NOTCH2","ITGAM","SIRPA","CX3CR1","CD1C",
  "CD1E","FCER1A","CCR6","NDRG2","PKIB","GRIP1","XCR1",
  "CLEC4C","LILRB4","NRP1",
  "CD38"
)

initial_plot <- DotPlot(bm_anno_myeloid, features = unique(allgene), scale = TRUE, cols = cols_vec)
save_plot_pdf(initial_plot, "dotplot_markers_default", w=14, h=8)

plot_data <- initial_plot$data

mat <- reshape2::dcast(plot_data, id ~ features.plot, value.var = "avg.exp.scaled")
rownames(mat) <- mat$id
mat$id <- NULL

clust <- hclust(dist(mat))
new_order <- clust$labels[clust$order]
plot_data$id <- factor(plot_data$id, levels = new_order)

p_dot_clustered <- ggplot(plot_data, aes(x = features.plot, y = id)) +
  geom_point(aes(size = pct.exp, fill = avg.exp.scaled), shape = 21, color = "black", stroke = 0) +
  scale_size(range = c(0, 8), name = "Percent Expressed") +
  scale_fill_gradientn(colors = blue_red_palette(100), name = "Average Expression") +
  theme_minimal() +
  theme(
    axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(color = "black")
  ) +
  labs(x = "Features", y = "Identity", title = "Clustered marker DotPlot")
save_plot_pdf(p_dot_clustered, "dotplot_markers_clustered", w=14, h=8)

# ----------------------------
# CD14 Mono: module-score tagging (Set1/Set2) + heat/scatter (saved)
# ----------------------------
monocytes <- msigdbr(species = "Homo sapiens", category = "C5", subcategory = "BP") %>%
  filter(gs_name == "GOBP_MONOCYTE_CHEMOTAXIS") %>%
  distinct(gene_symbol)

neutrophils <- msigdbr(species = "Homo sapiens", category = "C5", subcategory = "BP") %>%
  filter(gs_name == "GOBP_NEUTROPHIL_CHEMOTAXIS") %>%
  distinct(gene_symbol)

geneset1 <- monocytes$gene_symbol
geneset2 <- neutrophils$gene_symbol

# AddModuleScore creates Set11 / Set21
bm_anno_myeloid <- AddModuleScore(bm_anno_myeloid, features = list(geneset1), name = "Set1")
bm_anno_myeloid <- AddModuleScore(bm_anno_myeloid, features = list(geneset2), name = "Set2")

anno_col   <- "final_label"
cell_type  <- "CD14 Mono"

is_ct <- as.character(bm_anno_myeloid@meta.data[[anno_col]]) == cell_type

df <- bm_anno_myeloid@meta.data %>%
  tibble::as_tibble(rownames = "cell") %>%
  filter(.data[[anno_col]] == !!cell_type) %>%
  transmute(cell,
            set1 = Set11,
            set2 = Set21) %>%
  filter(is.finite(set1), is.finite(set2))

if (nrow(df) == 0) {
  log_msg("WARNING: No cells found for cell_type='", cell_type, "' in ", anno_col, ". Skipping CD14 tagging.")
} else {
  use_hex <- nrow(df) > 20000

  diag_prop_from_thresholds <- function(s1, s2, thr1, thr2) {
    lab1 <- ifelse(s1 >= thr1, "set1High", "set1Low")
    lab2 <- ifelse(s2 >= thr2, "set2High", "set2Low")
    mean((lab1 == "set1High" & lab2 == "set2Low") |
           (lab1 == "set1Low"  & lab2 == "set2High"),
         na.rm = TRUE)
  }

  s1 <- df$set1; s2 <- df$set2
  q_grid1 <- seq(0.30, 0.70, by = 0.02)
  q_grid2 <- seq(0.30, 0.70, by = 0.02)

  grid_tbl <- tidyr::crossing(q1 = q_grid1, q2 = q_grid2) %>%
    mutate(
      thr1 = as.numeric(map_dbl(q1, ~ quantile(s1, .x, na.rm = TRUE))),
      thr2 = as.numeric(map_dbl(q2, ~ quantile(s2, .x, na.rm = TRUE))),
      prop_diag = pmap_dbl(list(thr1, thr2), ~ diag_prop_from_thresholds(s1, s2, ..1, ..2)),
      dist_to_med = abs(q1 - 0.5) + abs(q2 - 0.5)
    )

  # Use MEDIAN thresholds per your current implementation
  thr1 <- median(s1, na.rm = TRUE)
  thr2 <- median(s2, na.rm = TRUE)
  prop_diag_q <- diag_prop_from_thresholds(s1, s2, thr1, thr2)

  best_row <- tibble::tibble(
    q1 = 0.50, q2 = 0.50,
    thr1 = thr1, thr2 = thr2,
    prop_diag = prop_diag_q,
    dist_to_med = 0
  )

  p_heat <- ggplot(grid_tbl, aes(q1, q2, fill = prop_diag)) +
    geom_tile() +
    scale_fill_viridis(name = "Diagonal fraction", limits = c(0,1)) +
    geom_point(data = best_row, aes(q1, q2), color = "white", size = 3, shape = 21, stroke = 0.6) +
    labs(x = "Quantile q1 for Set1 threshold",
         y = "Quantile q2 for Set2 threshold",
         title = paste0(cell_type, ": diagonal fraction across quantile cutoffs"),
         subtitle = sprintf("Selected q1=%.2f, q2=%.2f  →  diag=%.1f%%",
                            best_row$q1, best_row$q2, 100*prop_diag_q)) +
    theme_classic()
  save_plot_pdf(p_heat, "cd14_set1_set2_heatmap_diag_fraction", w=10, h=8)

  df_quads <- df %>%
    mutate(
      quad = case_when(
        set1 >= thr1 & set2 >= thr2 ~ "High-High",
        set1 >= thr1 & set2 <  thr2 ~ "High-Low",
        set1 <  thr1 & set2 >= thr2 ~ "Low-High",
        TRUE                        ~ "Low-Low"
      )
    )

  qcounts <- df_quads %>%
    count(quad) %>%
    tidyr::complete(quad = c("High-High","High-Low","Low-High","Low-Low"), fill = list(n = 0))

  padx <- (max(df$set1, na.rm=TRUE) - min(df$set1, na.rm=TRUE)) * 0.02
  pady <- (max(df$set2, na.rm=TRUE) - min(df$set2, na.rm=TRUE)) * 0.02

  labpos <- tibble::tibble(
    quad = c("High-High","High-Low","Low-High","Low-Low"),
    x = c(max(df$set1, na.rm=TRUE) - padx, max(df$set1, na.rm=TRUE) - padx,
          min(df$set1, na.rm=TRUE) + padx, min(df$set1, na.rm=TRUE) + padx),
    y = c(max(df$set2, na.rm=TRUE) - pady, min(df$set2, na.rm=TRUE) + pady,
          max(df$set2, na.rm=TRUE) - pady, min(df$set2, na.rm=TRUE) + pady),
    hjust = c(1,1,0,0),
    vjust = c(1,0,1,0)
  ) %>%
    left_join(qcounts, by = "quad") %>%
    mutate(label = paste0(quad, "\n(n=", n, ")"))

  p_scatter <- ggplot(df_quads, aes(x = set1, y = set2)) +
    { if (use_hex) geom_hex(bins = 50, alpha = 0.9) else
      geom_point(aes(color = quad), alpha = 0.5, size = 0.6) } +
    geom_vline(xintercept = thr1, linetype = "dashed") +
    geom_hline(yintercept = thr2, linetype = "dashed") +
    labs(x = "GOBP_MONOCYTE_CHEMOTAXIS (Set1)",
         y = "GOBP_NEUTROPHIL_CHEMOTAXIS (Set2)",
         title = paste0(cell_type, ": 2D distribution of signature scores"),
         subtitle = sprintf("Cutoffs → Set1 thr=%.3f, Set2 thr=%.3f; diagonal=%.1f%%",
                            thr1, thr2, 100*prop_diag_q)) +
    theme_classic() +
    { if (use_hex) scale_fill_viridis_c(option = "mako") else
      scale_color_viridis_d(option = "mako") } +
    geom_text(data = labpos, aes(x = x, y = y, label = label, hjust = hjust, vjust = vjust),
              size = 3.2)
  save_plot_pdf(p_scatter, "cd14_set1_set2_scatter_quadrants", w=10, h=8)

  # ---- WRITE TAGS BACK ----
  grp1_all <- ifelse(bm_anno_myeloid@meta.data$Set11 >= thr1, "set1High", "set1Low")
  grp2_all <- ifelse(bm_anno_myeloid@meta.data$Set21 >= thr2, "set2High", "set2Low")

  orig_lab <- as.character(bm_anno_myeloid@meta.data[[anno_col]])

  # IMPORTANT PATCH: remove spaces in the CD14 label prefix for stable downstream naming
  cell_type_key <- gsub("[[:space:]]+", "", cell_type)  # "CD14Mono"
  tag_lab <- ifelse(
    orig_lab == cell_type,
    paste0(cell_type_key, "_", grp1_all, "_", grp2_all),
    orig_lab
  )

  bm_anno_myeloid$CD14_tag <- NA_character_
  bm_anno_myeloid$CD14_tag[is_ct] <- paste0(grp1_all[is_ct], "_", grp2_all[is_ct])

  bm_anno_myeloid$Annotation <- tag_lab

  tab_cd14 <- table(bm_anno_myeloid$CD14_tag[is_ct], useNA = "ifany")
  diag_prop_final <- sum(tab_cd14[c("set1High_set2Low","set1Low_set2High")], na.rm = TRUE) / sum(tab_cd14)
  log_msg(sprintf("Final diagonal fraction in %s: %.1f%%", cell_type, 100*diag_prop_final))
  log_msg("CD14_tag table: ", paste(capture.output(print(tab_cd14)), collapse=" | "))

  # ----------------------------
  # UMAP_tag: keep CD14 subgroups; collapse others
  # ----------------------------
  bm_anno_myeloid$UMAP_tag <- ifelse(
    grepl("^CD14Mono_", bm_anno_myeloid$Annotation),
    bm_anno_myeloid$Annotation,
    "OtherCells"
  )

  # Stable plotting order
  labs <- unique(as.character(bm_anno_myeloid$UMAP_tag))
  tag_levels <- grep("^CD14Mono_", labs, value = TRUE)

  bm_anno_myeloid$UMAP_tag <- factor(
    bm_anno_myeloid$UMAP_tag,
    levels = c(sort(tag_levels), "OtherCells")
  )

  p_umap_tag <- DimPlot(
    bm_anno_myeloid,
    group.by  = "UMAP_tag",
    reduction = "umap",
    label     = TRUE
  )
  save_plot_pdf(p_umap_tag, "umap_cd14_tag_vs_othercells", w=12, h=8)
}

# ----------------------------
# NEW: Integrate final_label + UMAP_tag into Annotation_myeloid
# ----------------------------
final_label_chr <- as.character(bm_anno_myeloid$final_label)
umap_tag_chr    <- if ("UMAP_tag" %in% colnames(bm_anno_myeloid@meta.data)) as.character(bm_anno_myeloid$UMAP_tag) else rep(NA_character_, ncol(bm_anno_myeloid))

# Default rule:
# - If a cell is tagged (UMAP_tag not OtherCells and not NA), use UMAP_tag
# - Else fall back to final_label
anno_myeloid <- ifelse(!is.na(umap_tag_chr) & umap_tag_chr != "OtherCells", umap_tag_chr, final_label_chr)

# Apply requested CD14 renaming strategy
rename_map <- c(
  "CD14Mono_set1High_set2High" = "CD14Mono_neutrophil-like1",
  "CD14Mono_set1Low_set2High"  = "CD14Mono_neutrophil-like2",
  "CD14Mono_set1Low_set2Low"   = "CD14Mono_dendritic-like1",
  "CD14Mono_set1High_set2Low"  = "CD14Mono_dendritic-like2"
)

anno_myeloid <- dplyr::recode(anno_myeloid, !!!rename_map, .default = anno_myeloid)

bm_anno_myeloid$Annotation_myeloid <- factor(anno_myeloid, levels = sort(unique(anno_myeloid)))

# Plot final integrated annotation
p_umap_anno_myeloid <- DimPlot_scCustom(
  bm_anno_myeloid,
  pt.size = 0.5,
  reduction = "umap",
  group.by = "Annotation_myeloid",
  label = TRUE
)
save_plot_pdf(p_umap_anno_myeloid, "umap_annotation_myeloid_integrated", w=13, h=8)

bm_anno_myeloid@meta.data$barcode<-rownames(bm_anno_myeloid@meta.data)
label<-bm_anno_myeloid@meta.data[,c('barcode','Annotation_myeloid')]
write.csv(label,file=art_path('Mono.noverlabel.csv'))

# ----------------------------
# Save final object
# ----------------------------
out_rds <- work_path("bm_anno_myeloid_with_annotation_myeloid.rds")
saveRDS(bm_anno_myeloid, out_rds)
log_msg("Saved final Seurat object: ", out_rds)

log_msg("PRISM R step 3.2 finished successfully.")

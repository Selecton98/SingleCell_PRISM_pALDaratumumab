#!/usr/bin/env Rscript

# ============================
# PRISM standard CLI header (R) — Step 3 (Bcell) — PATCHED FULL SCRIPT v2
# Fixes:
# 1) featureplot_signature_scores_grid.pdf was empty -> ensure print() to PDF device
# 2) Old Sig_* columns (e.g., Sig_PlasmaCell_percentIG) being plotted -> only use Sig_* created THIS run
# ============================

suppressPackageStartupMessages({
  library(optparse)
  library(Seurat)
  library(ggplot2)
  library(scCustomize)
  library(patchwork)
  library(dplyr)
  library(tibble)
  library(tidyr)
  library(purrr)
  library(reshape2)
  library(readr)
})

set.seed(123)

# ----------------------------
# CLI options
# ----------------------------
option_list <- list(
  make_option(c("--output-dir"), type="character", default=".",
              help="Task output directory (root for logs/work/artifacts)"),
  make_option(c("--work-dir"), type="character", default=NA_character_,
              help="Working directory for intermediates (default: <output-dir>/work)"),
  make_option(c("--artifacts-dir"), type="character", default=NA_character_,
              help="Directory for final artifacts (default: <output-dir>/artifacts)"),
  make_option(c("--task-id"), type="integer", default=NA_integer_,
              help="Task ID (for logging/UI)"),
  make_option(c("--step-id"), type="character", default=NA_character_,
              help="Step ID like 3, 3.1, 3.2 (for logging/UI)"),
  make_option(c("--seurat-rds"), type="character", default=NA_character_,
              help="Path to input Seurat .rds (default: <work-dir>/sce1_nonplasmacell_lineage_Bcell.rds)"),

  # analysis params
  make_option(c("--dims"), type="integer", default=15,
              help="Number of PCA dims to use (default: 15)"),
  make_option(c("--resolution"), type="double", default=1.0,
              help="FindClusters resolution (default: 1.0)"),

  # annotation params
  make_option(c("--cluster-col"), type="character", default="seurat_clusters",
              help="Cluster column name to use (default: seurat_clusters)"),
  make_option(c("--anno-col"), type="character", default="Annotation_Bcell",
              help="Meta.data column to write per-cell annotation into (default: Annotation_Bcell)"),
  make_option(c("--min-score"), type="double", default=NA_real_,
              help="Optional: if best signature score < min-score, label as 'Unassigned'"),
  make_option(c("--min-delta"), type="double", default=NA_real_,
              help="Optional: if (best - second_best) < min-delta, label as 'Ambiguous'")
)

opt <- parse_args(OptionParser(option_list = option_list))

# ----------------------------
# Helpers
# ----------------------------
is_unset <- function(x) is.null(x) || length(x) == 0 || all(is.na(x)) || !nzchar(as.character(x)[1])
`%||%` <- function(a, b) if (!is_unset(a)) a else b

# Normalize CLI args robustly
opt$cluster_col <- opt$cluster_col %||% "seurat_clusters"
opt$anno_col    <- opt$anno_col %||% "Annotation_Bcell"
if (is.null(opt$min_score) || length(opt$min_score) == 0) opt$min_score <- NA_real_
if (is.null(opt$min_delta) || length(opt$min_delta) == 0) opt$min_delta <- NA_real_

log_msg <- function(...) {
  ts <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  cat(sprintf("[%s][task=%s][step=%s] ", ts, opt$task_id, opt$step_id),
      paste0(..., collapse=""), "\n")
}

require_file <- function(path, label) {
  if (is_unset(path)) stop(sprintf("Missing required input: %s", label))
  if (!file.exists(path)) stop(sprintf("File not found for %s: %s", label, path))
}

# ---- Resolve defaults ----
opt$output_dir    <- opt$output_dir %||% "."
opt$work_dir      <- opt$work_dir %||% file.path(opt$output_dir, "work")
opt$artifacts_dir <- opt$artifacts_dir %||% file.path(opt$output_dir, "artifacts")

dir.create(opt$output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$work_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$artifacts_dir, recursive = TRUE, showWarnings = FALSE)

work_path <- function(...) file.path(opt$work_dir, ...)
art_path  <- function(...) file.path(opt$artifacts_dir, ...)

# ---- Plot saving ----
plots_dir <- file.path(opt$artifacts_dir, "plots_step3")
dir.create(plots_dir, recursive = TRUE, showWarnings = FALSE)

plot_pdf_path <- function(name) {
  safe <- gsub("[[:space:]]+", "_", name)
  safe <- gsub("[^A-Za-z0-9_\\-\\.]", "", safe)
  file.path(plots_dir, paste0(safe, ".pdf"))
}

save_plot_pdf <- function(p, name, w=10, h=8) {
  out_pdf <- plot_pdf_path(name)
  device_fun <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(filename = out_pdf, plot = p, width = w, height = h, device = device_fun)
  log_msg("Saved plot: ", out_pdf)
  invisible(out_pdf)
}

# IMPORTANT FIX: print plot objects to device
save_base_pdf <- function(expr, name, w=10, h=8) {
  out_pdf <- plot_pdf_path(name)
  if (capabilities("cairo")) grDevices::cairo_pdf(out_pdf, width = w, height = h) else grDevices::pdf(out_pdf, width = w, height = h)
  on.exit(grDevices::dev.off(), add = TRUE)

  tryCatch({
    val <- force(expr)
    # If expr returns a plot object, print it; otherwise expr may have plotted already.
    if (inherits(val, "ggplot") || inherits(val, "patchwork")) {
      print(val)
    }
  }, error = function(e) {
    log_msg("WARNING base plot failed: ", name, " : ", conditionMessage(e))
  })

  log_msg("Saved plot: ", out_pdf)
  invisible(out_pdf)
}

# ----------------------------
# Signature sets (edit here)
# NOTE: PlasmaCell_percentIG REMOVED. If you want plasma identification, use PlasmaCell_Genes only.
# ----------------------------
ct_sigs <- list(
  "Naive_B"       = c("KCNG1","ZBTB16","IL4R","FCER2","PLPP5","CHI3L2","IGHD","SKAP1","CD200"),
  "Mature_B"      = c("SSPN","SIGLEC6","IGHA2","ZBTB32","TEX9","ST6GAL1","IL4I1","GPR18","CD27"),
  "Regulatory_B"  = c("DUSP26","SCHIP1","CD34","DEPP1","SHAB3","MMP28"),
  "Cycling_B"     = c("CDC25C","PBK","CKAP2L","UBE2C","E2F","MKI67","TOP2A","BIRC5","CCNB2"),
  "Activated_B"   = c("LAMP5","EMP2","PCOLCE2","TNFRSF13B","MZB1","DERL3"),
  "Plasmablast"   = c("SDC1","PRDM1","CD38")
)

# Marker list for DotPlot
allgene <- unique(c(
  "CD19","MS4A1","CD79A","CD34",
  ct_sigs$Naive_B,
  ct_sigs$Mature_B,
  ct_sigs$Activated_B,
  ct_sigs$Cycling_B,
  ct_sigs$Regulatory_B,
  ct_sigs$Plasmablast,
  "TOP2A","BIRC5","CCNB2"
))

# ----------------------------
# Utilities: scoring + annotation
# ----------------------------
add_signature_scores <- function(obj, sigs, assay="RNA", slot="data") {
  DefaultAssay(obj) <- assay

  sigs_present <- lapply(sigs, function(g) intersect(g, rownames(obj)))
  keep <- lengths(sigs_present) > 0
  if (!all(keep)) {
    dropped <- names(sigs_present)[!keep]
    log_msg("WARNING: Dropping signatures with 0 genes present: ", paste(dropped, collapse=", "))
  }
  sigs_present <- sigs_present[keep]
  if (length(sigs_present) == 0) stop("No signature genes found in object. Cannot score.")

  tmp_prefix <- "SigTmp_"
  obj <- AddModuleScore(obj, features = sigs_present, name = tmp_prefix, assay = assay, slot = slot, search = FALSE)

  k <- length(sigs_present)
  tmp_cols <- paste0(tmp_prefix, seq_len(k))
  new_cols <- paste0("Sig_", names(sigs_present))

  missing_tmp <- setdiff(tmp_cols, colnames(obj[[]]))
  if (length(missing_tmp) > 0) stop("Expected AddModuleScore columns not found: ", paste(missing_tmp, collapse=", "))

  md <- obj[[]]
  for (i in seq_len(k)) md[[new_cols[i]]] <- md[[tmp_cols[i]]]
  md[tmp_cols] <- NULL
  obj@meta.data <- md

  # CRITICAL FIX: store exactly which Sig_* columns were created this run
  attr(obj, "prism_sig_cols") <- new_cols

  log_msg("Added signature scores: ", paste(new_cols, collapse=", "))
  obj
}

annotate_cells_by_signature <- function(obj, sig_cols, anno_col,
                                        min_score = NA_real_, min_delta = NA_real_,
                                        unassigned_label="Unassigned", ambiguous_label="Ambiguous") {
  md <- obj[[]]
  stopifnot(all(sig_cols %in% colnames(md)))

  if (is.null(min_score) || length(min_score) == 0) min_score <- NA_real_
  if (is.null(min_delta) || length(min_delta) == 0) min_delta <- NA_real_

  if (is.null(anno_col) || length(anno_col) == 0) anno_col <- "Annotation_Bcell"
  anno_col <- as.character(anno_col)[1]
  if (!nzchar(anno_col)) anno_col <- "Annotation_Bcell"

  mat <- as.matrix(md[, sig_cols, drop=FALSE])
  best_idx <- max.col(mat, ties.method = "first")
  best_val <- mat[cbind(seq_len(nrow(mat)), best_idx)]
  second_val <- apply(mat, 1, function(x) sort(x, decreasing=TRUE)[2])
  delta <- best_val - second_val

  labels <- gsub("^Sig_", "", sig_cols)[best_idx]
  if (!is.na(min_score)) labels[best_val < min_score] <- unassigned_label
  if (!is.na(min_delta)) labels[delta < min_delta] <- ambiguous_label

  obj[[anno_col]] <- labels
  obj[[paste0(anno_col, "_best_score")]] <- best_val
  obj[[paste0(anno_col, "_delta12")]] <- delta

  log_msg("Wrote per-cell annotation into: ", anno_col)
  obj
}

predominant_signature_per_cluster <- function(obj, cluster_col, sig_cols) {
  md <- obj[[]]

  if (is.null(cluster_col) || length(cluster_col) == 0) cluster_col <- "seurat_clusters"
  cluster_col <- as.character(cluster_col)[1]
  if (!nzchar(cluster_col)) cluster_col <- "seurat_clusters"

  if (!cluster_col %in% colnames(md)) {
    log_msg("WARNING: cluster_col '", cluster_col, "' not found in meta.data; using Idents(obj) instead.")
    md$.cluster_fallback <- as.character(Idents(obj))
    cluster_col_use <- ".cluster_fallback"
  } else {
    cluster_col_use <- cluster_col
  }

  stopifnot(all(sig_cols %in% colnames(md)))

  df <- md %>%
    rownames_to_column("cell") %>%
    mutate(.cluster = .data[[cluster_col_use]]) %>%
    select(cell, .cluster, all_of(sig_cols))

  cluster_means <- df %>%
    group_by(.cluster) %>%
    summarise(across(all_of(sig_cols), ~mean(.x, na.rm = TRUE)), .groups = "drop")

  out <- cluster_means %>%
    rowwise() %>%
    mutate(
      best_sig_col = sig_cols[which.max(c_across(all_of(sig_cols)))],
      best_sig     = gsub("^Sig_", "", best_sig_col),
      best_mean    = max(c_across(all_of(sig_cols)))
    ) %>%
    ungroup() %>%
    arrange(.cluster)

  out
}

# ----------------------------
# Start
# ----------------------------
log_msg("PRISM Step 3 (Bcell) starting")
log_msg("output_dir: ", opt$output_dir)
log_msg("work_dir: ", opt$work_dir)
log_msg("artifacts_dir: ", opt$artifacts_dir)
log_msg("cluster_col: ", opt$cluster_col)
log_msg("anno_col: ", opt$anno_col)

seurat_rds <- opt$seurat_rds %||% work_path("sce1_nonplasmacell_lineage_Bcell.rds")
require_file(seurat_rds, "--seurat-rds or <work-dir>/sce1_nonplasmacell_lineage_Bcell.rds")

log_msg("Loading Seurat object: ", seurat_rds)
obj <- readRDS(seurat_rds)
if (!inherits(obj, "Seurat")) stop("Loaded object is not a Seurat object: ", seurat_rds)

DefaultAssay(obj) <- "RNA"

# ----------------------------
# Standard Seurat workflow
# ----------------------------
log_msg("NormalizeData / FindVariableFeatures")
obj <- NormalizeData(obj, verbose = FALSE)
obj <- FindVariableFeatures(obj, verbose = FALSE)

log_msg("ScaleData / RunPCA")
obj <- ScaleData(obj, features = VariableFeatures(obj), verbose = FALSE)
obj <- RunPCA(obj, features = VariableFeatures(obj), verbose = FALSE)

dims_use <- seq_len(opt$dims)

log_msg("FindNeighbors / FindClusters / RunUMAP")
obj <- FindNeighbors(obj, dims = dims_use, reduction = "pca", verbose = FALSE)
obj <- FindClusters(obj, resolution = opt$resolution, cluster.name = opt$cluster_col, verbose = FALSE)
obj <- RunUMAP(obj, dims = dims_use, reduction = "pca", reduction.name = "umap", verbose = FALSE)

# ----------------------------
# Plots: UMAP
# ----------------------------
p_umap_clusters <- DimPlot_scCustom(obj, pt.size=0.6, reduction="umap", group.by=opt$cluster_col, label=TRUE)
save_plot_pdf(p_umap_clusters, "umap_clusters", w=10, h=8)

if ("orig.ident" %in% colnames(obj[[]])) {
  p_umap_orig <- DimPlot_scCustom(obj, pt.size=0.6, reduction="umap", group.by="orig.ident", label=FALSE)
  save_plot_pdf(p_umap_orig, "umap_orig_ident", w=10, h=8)
} else {
  log_msg("Skipping orig.ident UMAP: orig.ident not found in meta.data.")
}

# ----------------------------
# Marker DotPlot
# ----------------------------
cols_vec <- colorRampPalette(c("steelblue", "white", "firebrick"))(26)
blue_red_palette <- colorRampPalette(c("steelblue", "white", "firebrick"))

allgene_present <- intersect(unique(allgene), rownames(obj))
if (length(allgene_present) == 0) stop("No DotPlot genes found in object (after intersection).")

p_dot_default <- DotPlot(obj, features = allgene_present, cols = cols_vec, scale = TRUE) +
  RotatedAxis() + ggtitle("Marker DotPlot (default order)")
save_plot_pdf(p_dot_default, "dotplot_markers_default", w=16, h=8)

tryCatch({
  plot_data <- p_dot_default$data
  mat <- reshape2::dcast(plot_data, id ~ features.plot, value.var = "avg.exp.scaled")
  rownames(mat) <- mat$id
  mat$id <- NULL
  clust <- hclust(dist(mat))
  new_order <- clust$labels[clust$order]
  plot_data$id <- factor(plot_data$id, levels = new_order)

  p_dot_clustered <- ggplot(plot_data, aes(x = features.plot, y = id)) +
    geom_point(aes(size = pct.exp, fill = avg.exp.scaled), shape = 21, color = "black", stroke = 0) +
    scale_size(range = c(0, 8), name = "Percent Expressed") +
    scale_fill_gradientn(colors = blue_red_palette(100), name = "Average Expression") +
    theme_minimal() +
    theme(
      axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      axis.line = element_line(color = "black")
    ) +
    labs(x = "Features", y = "Cluster", title = "Marker DotPlot (cluster-reordered)")
  save_plot_pdf(p_dot_clustered, "dotplot_markers_clustered", w=16, h=8)
}, error = function(e) {
  log_msg("WARNING: clustered DotPlot reorder failed: ", conditionMessage(e))
})

# ----------------------------
# Signature scoring + annotation
# ----------------------------
log_msg("Computing signature scores (Sig_<name>)")
obj <- add_signature_scores(obj, ct_sigs, assay="RNA", slot="data")

# CRITICAL FIX: only use Sig_* columns created in THIS run
sig_cols <- attr(obj, "prism_sig_cols")
if (is.null(sig_cols) || length(sig_cols) == 0) stop("No prism_sig_cols attribute found; signature scoring likely failed.")
sig_cols <- sig_cols[sig_cols %in% colnames(obj[[]])]
if (length(sig_cols) == 0) stop("No Sig_* columns from this run exist in meta.data; cannot annotate/plot.")

obj <- annotate_cells_by_signature(
  obj,
  sig_cols = sig_cols,
  anno_col = opt$anno_col,
  min_score = opt$min_score,
  min_delta = opt$min_delta
)

p_umap_anno <- DimPlot_scCustom(obj, pt.size=0.6, reduction="umap", group.by=opt$anno_col, label=TRUE)
save_plot_pdf(p_umap_anno, "umap_signature_annotation", w=12, h=8)

# FIXED: print patchwork to device -> non-empty PDF
save_base_pdf({
  fp_list <- lapply(sig_cols, function(cc) FeaturePlot(obj, features = cc, reduction="umap") + ggtitle(cc))
  wrap_plots(fp_list, ncol = 3)
}, "featureplot_signature_scores_grid", w=16, h=12)

# ----------------------------
# Per-cluster predominant signature table (mean score)
# ----------------------------
pred_tbl <- predominant_signature_per_cluster(obj, cluster_col = opt$cluster_col, sig_cols = sig_cols)

anno_counts <- as.data.frame(table(obj[[opt$anno_col]][,1]))
colnames(anno_counts) <- c("label", "n_cells")

p_counts <- ggplot(anno_counts, aes(x = label, y = n_cells)) +
  geom_col() +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(x = opt$anno_col, y = "Cells", title = "Annotation counts")
save_plot_pdf(p_counts, "annotation_counts_barplot", w=10, h=6)

obj@meta.data$barcode<-rownames(obj@meta.data)
label<-obj@meta.data[,c('barcode','anno_col')]
write.csv(label,file=art_path('Bcell.noverlabel.csv'))

# ----------------------------
# Save final object
# ----------------------------
out_rds <- work_path("sce1_Bcell_annotated.rds")
saveRDS(obj, out_rds)
log_msg("Saved final Seurat object: ", out_rds)

log_msg("PRISM Step 3.4 finished successfully.")

#!/usr/bin/env python3
"""
PRISM-style starCAT for T cells (TCAT)

Mirrors the plasma-cell PRISM framework (outdir structure, caching policy, counts-layer
selection, plotting to PDF, exporting tables), while keeping the "original" TCAT workflow:
  - tcat = starCAT(reference='TCAT.V1', cachedir=...)
  - usage, scores = tcat.fit_transform(adata)
  - merge usage and scores into adata.obs
  - cast *_binary score columns to str
  - export obs/var TSVs

Outputs (all under --outdir):
  - plots/        (PDFs)
  - tables/       (TSVs/CSVs)
  - anndata/      (updated .h5ad)
  - cache/        (starCAT cache by default)
"""

from __future__ import annotations

import argparse
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import scanpy as sc
import matplotlib.pyplot as plt

from starcat import starCAT


# -----------------------------
# PRISM utilities (shared style)
# -----------------------------
def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_name(s: str) -> str:
    s = str(s)
    s = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in s)
    while "__" in s:
        s = s.replace("__", "_")
    return s.strip("_")


def log_kv(title: str, kv: Dict[str, Any]) -> None:
    print(f"\n[{title}]")
    for k, v in kv.items():
        print(f"  - {k}: {v}")


def choose_counts_matrix(adata: sc.AnnData, preferred_layer: str = "counts") -> Tuple[str, bool]:
    """
    Ensures adata.X is a non-negative matrix suitable for starCAT/NMF.
    Priority:
      1) adata.layers[preferred_layer] if present
      2) adata.raw.X if present
      3) adata.X as-is

    Returns:
      (source_label, is_integer_like)
    """
    source = "X"
    X = adata.X

    if preferred_layer and (preferred_layer in adata.layers):
        X = adata.layers[preferred_layer]
        adata.X = X
        source = f"layers['{preferred_layer}']"
    elif adata.raw is not None and adata.raw.X is not None:
        X = adata.raw.X
        adata.X = X
        source = "raw.X"

    # Nonnegative check
    try:
        if hasattr(adata.X, "data"):  # sparse
            min_val = float(np.min(adata.X.data)) if adata.X.data.size else 0.0
        else:
            min_val = float(np.nanmin(adata.X))
    except Exception:
        min_val = 0.0

    if min_val < 0:
        print(
            f"\n[WARN] Detected negative values in {source} (min={min_val}). "
            "Not suitable for NMF-based fitting. If this came from scaled data, "
            "switch to raw counts. Proceeding by clipping negatives to 0 (stopgap)."
        )
        if hasattr(adata.X, "data"):
            adata.X.data = np.maximum(adata.X.data, 0)
        else:
            adata.X = np.maximum(adata.X, 0)

    # Integer-like check
    is_int_like = False
    try:
        vals = adata.X.data if hasattr(adata.X, "data") else np.ravel(adata.X)
        if vals.size:
            samp = vals[: min(vals.size, 2000)]
            is_int_like = bool(np.all(np.isfinite(samp)) and np.all(np.abs(samp - np.round(samp)) < 1e-6))
        else:
            is_int_like = True
    except Exception:
        is_int_like = False

    return source, is_int_like


@dataclass
class PRISMPaths:
    outdir: Path
    plots_dir: Path
    tables_dir: Path
    anndata_dir: Path
    cache_dir: Path

    @staticmethod
    def build(outdir: str, cache_dir: Optional[str]) -> "PRISMPaths":
        outdir_p = ensure_dir(Path(outdir).resolve())

        if cache_dir is None:
            cache_p = outdir_p / "cache"
        else:
            cache_candidate = Path(cache_dir)
            cache_p = cache_candidate if cache_candidate.is_absolute() else (outdir_p / cache_candidate)

        return PRISMPaths(
            outdir=outdir_p,
            plots_dir=ensure_dir(outdir_p / "plots"),
            tables_dir=ensure_dir(outdir_p / "tables"),
            anndata_dir=ensure_dir(outdir_p / "anndata"),
            cache_dir=ensure_dir(cache_p),
        )

    def plot_pdf_path(self, name: str) -> Path:
        return self.plots_dir / f"{safe_name(name)}.pdf"

    def table_path(self, name: str, suffix: str = ".tsv") -> Path:
        return self.tables_dir / f"{safe_name(name)}{suffix}"

    def anndata_path(self, name: str) -> Path:
        return self.anndata_dir / f"{safe_name(name)}.h5ad"


def plot_umap_to_pdf(
    adata: sc.AnnData,
    colors: List[str],
    pdf_path: Path,
    ncols: int = 4,
    vmin: Optional[float] = 0,
    vmax: Optional[str] = "p99",
    size: float = 8,
    cmap: Optional[str] = "turbo",
    title: Optional[str] = None,
) -> None:
    pdf_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        sc.pl.umap(
            adata,
            color=colors,
            ncols=ncols,
            vmin=vmin,
            vmax=vmax,
            size=size,
            color_map=cmap,
            show=False,
            wspace=0.3,
        )
        if title:
            plt.suptitle(title, y=1.02)

        fig = plt.gcf()
        fig.savefig(pdf_path, bbox_inches="tight")
        plt.close(fig)

    except Exception as e:
        # fail-loud, so you see it in stdout/stderr logs
        raise RuntimeError(f"Failed to generate plot PDF: {pdf_path}") from e

    # verify the file is really there and non-trivial
    if (not pdf_path.exists()) or pdf_path.stat().st_size < 1024:
        raise RuntimeError(
            f"Plot PDF was not created correctly (missing or too small): {pdf_path} "
            f"(size={pdf_path.stat().st_size if pdf_path.exists() else 'NA'} bytes)"
        )

# -----------------------------
# Core TCAT steps (original behavior preserved)
# -----------------------------
def run_tcat_fit_transform(
    adata: sc.AnnData,
    reference: str,
    cache_dir: Path,
) -> Tuple[pd.DataFrame, pd.DataFrame, starCAT]:
    """
    Preserves the canonical TCAT snippet behavior:
      usage, scores = tcat.fit_transform(adata)
    Returns (usage, scores, tcat)
    """
    tcat = starCAT(reference=reference, cachedir=str(cache_dir))
    usage, scores = tcat.fit_transform(adata)

    # Align indices to adata.obs_names if needed
    if not usage.index.equals(adata.obs_names):
        usage = usage.reindex(adata.obs_names)
    if not scores.index.equals(adata.obs_names):
        scores = scores.reindex(adata.obs_names)

    return usage, scores, tcat


def merge_usage_scores_into_obs(adata: sc.AnnData, usage: pd.DataFrame, scores: pd.DataFrame) -> None:
    # Usage should be numeric
    for col in usage.columns:
        adata.obs[col] = pd.to_numeric(usage[col], errors="coerce")

    # Preserve original behavior: cast *_binary score columns to str
    score_cols = list(scores.columns)
    binary_cols = [c for c in score_cols if "_binary" in c]
    if len(binary_cols) > 0:
        scores = scores.copy()
        scores[binary_cols] = scores[binary_cols].astype("str")

    # Merge scores (keep as-is; user may have mixed types)
    for col in scores.columns:
        adata.obs[col] = scores[col]


def coerce_categories_to_str(df: pd.DataFrame, index_name: str) -> pd.DataFrame:
    out = df.copy()
    for c in out.select_dtypes(include="category").columns:
        out[c] = out[c].astype(str)
    out.index.name = index_name
    return out


# -----------------------------
# CLI
# -----------------------------
def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="PRISM: TCAT starCAT usage + scores (T cells)")
    p.add_argument("--h5ad", required=True, help="Input AnnData .h5ad (should already have UMAP if plotting)")
    p.add_argument("--outdir", required=True, help="Work directory (all outputs go under here)")

    p.add_argument(
        "--reference",
        default="TCAT.V1",
        help="starCAT built-in reference name for T cells (default: TCAT.V1)",
    )

    p.add_argument(
        "--cache-dir",
        default=None,
        help="Cache directory. If relative, it will be placed under --outdir. Default: --outdir/cache",
    )

    p.add_argument(
        "--counts-layer",
        default="counts",
        help="Preferred AnnData layer to use as counts matrix (default: 'counts'). "
             "If not present, script will try adata.raw.X, then adata.X.",
    )

    p.add_argument(
        "--plot",
        action="store_true",
        help="If set, produce UMAP PDFs. Requires adata.obsm['X_umap'].",
    )

    p.add_argument(
        "--plot-usage-prefix",
        default=None,
        help="If set, plot usage columns whose names start with this prefix (e.g., 'GEP'). "
             "If not set, plot all usage columns (can be many).",
    )

    p.add_argument(
        "--plot-score-cols",
        nargs="*",
        default=["Multinomial_Label"],
        help="Score/label columns to plot (if present). Default: Multinomial_Label",
    )

    p.add_argument(
        "--write-h5ad",
        action="store_true",
        help="If set, write updated AnnData (with usage+scores in obs) to anndata/.",
    )

    p.add_argument(
        "--prefix",
        default="tcell",
        help="Prefix for output filenames (default: tcell).",
    )

    return p


def main() -> None:
    args = build_argparser().parse_args()
    paths = PRISMPaths.build(args.outdir, args.cache_dir)

    log_kv(
        "Inputs",
        {
            "h5ad": args.h5ad,
            "reference": args.reference,
            "outdir": str(paths.outdir),
            "plots_dir": str(paths.plots_dir),
            "tables_dir": str(paths.tables_dir),
            "anndata_dir": str(paths.anndata_dir),
            "cache_dir": str(paths.cache_dir),
            "counts_layer": args.counts_layer,
            "plot": args.plot,
            "write_h5ad": args.write_h5ad,
            "prefix": args.prefix,
        },
    )

    # 1) Load
    adata = sc.read_h5ad(args.h5ad)
    log_kv("AnnData", {"n_obs": adata.n_obs, "n_vars": adata.n_vars})

    # 2) Ensure counts matrix for starCAT
    source, is_int_like = choose_counts_matrix(adata, preferred_layer=args.counts_layer)
    if not is_int_like:
        print(
            f"\n[WARN] starCAT expects integer counts; using {source} which does not look integer-like. "
            "If you have raw counts, store them in adata.layers['counts'] and rerun."
        )
    else:
        print(f"\n[OK] Using {source} as query matrix for starCAT (looks integer-like).")

    # 3) Run TCAT (preserve original behavior)
    usage, scores, tcat = run_tcat_fit_transform(adata, reference=args.reference, cache_dir=paths.cache_dir)

    # Optional: print reference info like your notebook does (lightweight, non-intrusive)
    print(f"\n[starCAT] ref_name: {getattr(tcat, 'ref_name', args.reference)}")
    try:
        ref_df = getattr(tcat, "ref", None)
        if isinstance(ref_df, pd.DataFrame):
            print("\n[starCAT] ref (top-left 5x5):")
            print(ref_df.iloc[:5, :5])
    except Exception:
        pass

    try:
        score_data = getattr(tcat, "score_data", None)
        if score_data is not None:
            print("\n[starCAT] score_data:")
            print(score_data)
    except Exception:
        pass

    # 4) Merge into obs
    merge_usage_scores_into_obs(adata, usage=usage, scores=scores)

    # 5) Export obs/var as TSVs (category->str)
    obs = coerce_categories_to_str(adata.obs, index_name="cell_id")
    var = coerce_categories_to_str(adata.var, index_name="gene")

    obs_path = paths.table_path(f"{args.prefix}_STAR_adata_obs", suffix=".tsv")
    var_path = paths.table_path(f"{args.prefix}_STAR_adata_var", suffix=".tsv")
    obs.to_csv(obs_path, sep="\t")
    var.to_csv(var_path, sep="\t")
    print(f"\nWrote: {obs_path}")
    print(f"Wrote: {var_path}")

    # Also save raw usage/scores tables explicitly (often helpful downstream)
    usage_path = paths.table_path(f"{args.prefix}_STAR_usage", suffix=".tsv")
    scores_path = paths.table_path(f"{args.prefix}_STAR_scores", suffix=".tsv")
    usage.to_csv(usage_path, sep="\t", index=True)
    scores.to_csv(scores_path, sep="\t", index=True)
    print(f"Wrote: {usage_path}")
    print(f"Wrote: {scores_path}")

    # 6) Plotting
    if args.plot:
        if "X_umap" not in adata.obsm_keys():
            raise ValueError("Requested --plot but adata.obsm['X_umap'] not found. Run UMAP first.")

        # Usage columns selection
        if args.plot_usage_prefix:
            usage_cols = [c for c in usage.columns if str(c).startswith(args.plot_usage_prefix)]
        else:
            usage_cols = list(usage.columns)

        if len(usage_cols) > 0:
            pdf = paths.plot_pdf_path(f"{args.prefix}_umap_starcat_usage")
            plot_umap_to_pdf(
                adata,
                colors=usage_cols,
                pdf_path=pdf,
                ncols=4,
                vmin=0,
                vmax="p99",
                size=8,
                cmap="turbo",
                title=f"TCAT usage ({args.reference})",
            )
            print(f"Wrote: {pdf}")

        # Score/label columns (categorical-friendly)
        score_plot_cols = [c for c in (args.plot_score_cols or []) if c in adata.obs.columns]
        if len(score_plot_cols) > 0:
            pdf = paths.plot_pdf_path(f"{args.prefix}_umap_starcat_scores")
            sc.pl.umap(
                adata,
                color=score_plot_cols,
                show=False,
                legend_loc="right margin",
                legend_fontsize=8,
                size=8,
                wspace=0.3,
            )
            plt.savefig(pdf, bbox_inches="tight")
            plt.close()
            print(f"Wrote: {pdf}")

    # 7) Save updated h5ad
    if args.write_h5ad:
        out_h5ad = paths.anndata_path(f"{args.prefix}_STAR")
        adata.write_h5ad(out_h5ad)
        print(f"\nWrote: {out_h5ad}")

    log_kv(
        "PRISM R step 3.3 finished successfully.",
        {
            "plots_dir": str(paths.plots_dir),
            "tables_dir": str(paths.tables_dir),
            "anndata_dir": str(paths.anndata_dir),
            "cache_dir": str(paths.cache_dir),
        },
    )

# -----------------------------
# Export barcode + final_label (R -> Python)
# -----------------------------
# In AnnData, cell barcodes are typically adata.obs_names.
# Ensure "barcode" column exists and equals obs_names.
adata.obs["barcode"] = adata.obs_names.astype(str)

# Build the label table (barcode, final_label) and write to CSV
if "final_label" not in adata.obs.columns:
    raise KeyError("adata.obs does not contain 'final_label'. Create it before exporting.")

label = adata.obs.loc[:, ["barcode", "final_label"]].copy()

out_csv = paths.outdir("Tcell.noverlabel", suffix=".csv") 
label.to_csv(out_csv, index=False)
print(f"Wrote: {out_csv}")

if __name__ == "__main__":
    main()

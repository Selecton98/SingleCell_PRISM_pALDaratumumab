#!/usr/bin/env Rscript

# ============================
# PRISM standard CLI header (R) — Step 3 (NKcell) — STREAMLINED + ROBUST
# Principles implemented:
# 1) Annotate by signature score (single term OR a composite of 2+ terms)
# 2) Only use Sig_* columns created in THIS run (avoid legacy Sig_* contamination)
# 3) Save all plots under artifacts/plots_step3
# 4) Add/Update "Nover" in meta.data with NK annotation as the PREFIX
#    - If Nover exists:  Nover <- "NK_<label>__<oldNover>"
#    - If Nover missing: Nover <- "NK_<label>"
# ============================

suppressPackageStartupMessages({
  library(optparse)
  library(Seurat)
  library(ggplot2)
  library(scCustomize)
  library(patchwork)
  library(dplyr)
  library(tibble)
  library(tidyr)
  library(reshape2)
  library(readr)
})

set.seed(123)

# ----------------------------
# CLI options
# ----------------------------
option_list <- list(
  make_option(c("--output-dir"), type="character", default=".",
              help="Task output directory (root for logs/work/artifacts)"),
  make_option(c("--work-dir"), type="character", default=NA_character_,
              help="Working directory for intermediates (default: <output-dir>/work)"),
  make_option(c("--artifacts-dir"), type="character", default=NA_character_,
              help="Directory for final artifacts (default: <output-dir>/artifacts)"),
  make_option(c("--task-id"), type="integer", default=NA_integer_,
              help="Task ID (for logging/UI)"),
  make_option(c("--step-id"), type="character", default=NA_character_,
              help="Step ID like 3, 3.1, 3.2 (for logging/UI)"),
  make_option(c("--seurat-rds"), type="character", default=NA_character_,
              help="Path to input Seurat .rds (default: <work-dir>/sce1_nonplasmacell_lineage_NKcell.rds)"),

  # analysis params
  make_option(c("--dims"), type="integer", default=15,
              help="Number of PCA dims to use (default: 15)"),
  make_option(c("--resolution"), type="double", default=1.0,
              help="FindClusters resolution (default: 1.0)"),

  # annotation params
  make_option(c("--cluster-col"), type="character", default="seurat_clusters",
              help="Cluster column name to use (default: seurat_clusters)"),
  make_option(c("--anno-col"), type="character", default="Annotation_NKcell",
              help="Meta.data column to write NK annotation into (default: Annotation_NKcell)"),
  make_option(c("--min-score"), type="double", default=NA_real_,
              help="Optional: if best signature score < min-score, label as 'Unassigned'"),
  make_option(c("--min-delta"), type="double", default=NA_real_,
              help="Optional: if (best - second_best) < min-delta, label as 'Ambiguous'")
)

opt <- parse_args(OptionParser(option_list = option_list))

# ----------------------------
# Helpers
# ----------------------------
is_unset <- function(x) is.null(x) || length(x) == 0 || all(is.na(x)) || !nzchar(as.character(x)[1])
`%||%` <- function(a, b) if (!is_unset(a)) a else b

# Normalize CLI args robustly
opt$cluster_col <- opt$cluster_col %||% "seurat_clusters"
opt$anno_col    <- opt$anno_col %||% "Annotation_NKcell"
if (is.null(opt$min_score) || length(opt$min_score) == 0) opt$min_score <- NA_real_
if (is.null(opt$min_delta) || length(opt$min_delta) == 0) opt$min_delta <- NA_real_

log_msg <- function(...) {
  ts <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  cat(sprintf("[%s][task=%s][step=%s] ", ts, opt$task_id, opt$step_id),
      paste0(..., collapse=""), "\n")
}

require_file <- function(path, label) {
  if (is_unset(path)) stop(sprintf("Missing required input: %s", label))
  if (!file.exists(path)) stop(sprintf("File not found for %s: %s", label, path))
}

# ---- Resolve defaults ----
opt$output_dir    <- opt$output_dir %||% "."
opt$work_dir      <- opt$work_dir %||% file.path(opt$output_dir, "work")
opt$artifacts_dir <- opt$artifacts_dir %||% file.path(opt$output_dir, "artifacts")

dir.create(opt$output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$work_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$artifacts_dir, recursive = TRUE, showWarnings = FALSE)

work_path <- function(...) file.path(opt$work_dir, ...)
plots_dir <- file.path(opt$artifacts_dir, "plots_step3")
dir.create(plots_dir, recursive = TRUE, showWarnings = FALSE)

plot_pdf_path <- function(name) {
  safe <- gsub("[[:space:]]+", "_", name)
  safe <- gsub("[^A-Za-z0-9_\\-\\.]", "", safe)
  file.path(plots_dir, paste0(safe, ".pdf"))
}

save_plot_pdf <- function(p, name, w=10, h=8) {
  out_pdf <- plot_pdf_path(name)
  device_fun <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(filename = out_pdf, plot = p, width = w, height = h, device = device_fun)
  log_msg("Saved plot: ", out_pdf)
  invisible(out_pdf)
}

# IMPORTANT: print plot objects to device (prevents empty PDFs)
save_base_pdf <- function(expr, name, w=10, h=8) {
  out_pdf <- plot_pdf_path(name)
  if (capabilities("cairo")) grDevices::cairo_pdf(out_pdf, width = w, height = h) else grDevices::pdf(out_pdf, width = w, height = h)
  on.exit(grDevices::dev.off(), add = TRUE)

  tryCatch({
    val <- force(expr)
    if (inherits(val, "ggplot") || inherits(val, "patchwork")) print(val)
  }, error = function(e) {
    log_msg("WARNING base plot failed: ", name, " : ", conditionMessage(e))
  })

  log_msg("Saved plot: ", out_pdf)
  invisible(out_pdf)
}

# ----------------------------
# NK signature sets (edit here)
# - Use single terms OR build composite terms later
# ----------------------------
ct_sigs <- list(
  immature     = c("TCF7","SELL","IL7R","XCL1","XCL2"),
  terminal     = c("KLRC1","KLRG1","KLRD1"),
  cytokine     = c("IFNG","TNF","IL10"),
  cytotoxic    = c("PRF1","GZMB","GZMA"),
  translational = c("CXCR6","TIGIT","IFNG")
)

# Marker list for DotPlot
allgene <- unique(unlist(ct_sigs, use.names = FALSE))

# ----------------------------
# Utilities: scoring + annotation
# ----------------------------
add_signature_scores <- function(obj, sigs, assay="RNA", slot="data") {
  DefaultAssay(obj) <- assay

  sigs_present <- lapply(sigs, function(g) intersect(g, rownames(obj)))
  keep <- lengths(sigs_present) > 0
  if (!all(keep)) {
    dropped <- names(sigs_present)[!keep]
    log_msg("WARNING: Dropping signatures with 0 genes present: ", paste(dropped, collapse=", "))
  }
  sigs_present <- sigs_present[keep]
  if (length(sigs_present) == 0) stop("No signature genes found in object. Cannot score.")

  tmp_prefix <- "SigTmp_"
  obj <- AddModuleScore(obj, features = sigs_present, name = tmp_prefix, assay = assay, slot = slot, search = FALSE)

  k <- length(sigs_present)
  tmp_cols <- paste0(tmp_prefix, seq_len(k))
  new_cols <- paste0("Sig_", names(sigs_present))

  missing_tmp <- setdiff(tmp_cols, colnames(obj[[]]))
  if (length(missing_tmp) > 0) stop("Expected AddModuleScore columns not found: ", paste(missing_tmp, collapse=", "))

  md <- obj[[]]
  for (i in seq_len(k)) md[[new_cols[i]]] <- md[[tmp_cols[i]]]
  md[tmp_cols] <- NULL
  obj@meta.data <- md

  # Store exactly which Sig_* were created this run
  attr(obj, "prism_sig_cols") <- new_cols

  log_msg("Added signature scores: ", paste(new_cols, collapse=", "))
  obj
}

# Composite signature builder:
# - Create "Sig_<new_name>" as weighted sum of existing Sig_* cols
# - weights named by term WITHOUT "Sig_" prefix, e.g. c(cytotoxic=1, terminal=1)
add_composite_signature <- function(obj, new_name, weights_named_terms) {
  stopifnot(is.character(new_name), length(new_name) == 1, nzchar(new_name))
  md <- obj[[]]

  # Translate terms -> Sig columns
  terms <- names(weights_named_terms)
  if (is.null(terms) || any(!nzchar(terms))) stop("weights_named_terms must be a named numeric vector (names are terms).")
  sig_cols <- paste0("Sig_", terms)

  missing <- setdiff(sig_cols, colnames(md))
  if (length(missing) > 0) stop("Composite requested missing Sig columns: ", paste(missing, collapse=", "))

  w <- as.numeric(weights_named_terms)
  names(w) <- sig_cols

  mat <- as.matrix(md[, sig_cols, drop=FALSE])
  comp <- as.numeric(mat %*% w)

  new_col <- paste0("Sig_", new_name)
  obj[[new_col]] <- comp

  # Track as "this-run" sig columns too (so downstream plots use it)
  sig_run <- attr(obj, "prism_sig_cols")
  if (is.null(sig_run)) sig_run <- character(0)
  attr(obj, "prism_sig_cols") <- unique(c(sig_run, new_col))

  log_msg("Added composite signature: ", new_col, " = sum(", paste0(sig_cols, "*w", collapse=" + "), ")")
  obj
}

# Annotation by best signature
annotate_cells_by_signature <- function(obj, sig_cols, anno_col,
                                        min_score = NA_real_, min_delta = NA_real_,
                                        unassigned_label="Unassigned", ambiguous_label="Ambiguous") {
  md <- obj[[]]
  stopifnot(all(sig_cols %in% colnames(md)))

  if (is.null(min_score) || length(min_score) == 0) min_score <- NA_real_
  if (is.null(min_delta) || length(min_delta) == 0) min_delta <- NA_real_

  if (is.null(anno_col) || length(anno_col) == 0) anno_col <- "Annotation_NKcell"
  anno_col <- as.character(anno_col)[1]
  if (!nzchar(anno_col)) anno_col <- "Annotation_NKcell"

  mat <- as.matrix(md[, sig_cols, drop=FALSE])
  best_idx <- max.col(mat, ties.method = "first")
  best_val <- mat[cbind(seq_len(nrow(mat)), best_idx)]
  second_val <- apply(mat, 1, function(x) sort(x, decreasing=TRUE)[2])
  delta <- best_val - second_val

  labels <- gsub("^Sig_", "", sig_cols)[best_idx]
  if (!is.na(min_score)) labels[best_val < min_score] <- unassigned_label
  if (!is.na(min_delta)) labels[delta < min_delta] <- ambiguous_label

  obj[[anno_col]] <- labels
  obj[[paste0(anno_col, "_best_score")]] <- best_val
  obj[[paste0(anno_col, "_delta12")]] <- delta

  log_msg("Wrote per-cell annotation into: ", anno_col)
  obj
}

predominant_signature_per_cluster <- function(obj, cluster_col, sig_cols) {
  md <- obj[[]]

  if (is.null(cluster_col) || length(cluster_col) == 0) cluster_col <- "seurat_clusters"
  cluster_col <- as.character(cluster_col)[1]
  if (!nzchar(cluster_col)) cluster_col <- "seurat_clusters"

  if (!cluster_col %in% colnames(md)) {
    log_msg("WARNING: cluster_col '", cluster_col, "' not found in meta.data; using Idents(obj) instead.")
    md$.cluster_fallback <- as.character(Idents(obj))
    cluster_col_use <- ".cluster_fallback"
  } else {
    cluster_col_use <- cluster_col
  }

  stopifnot(all(sig_cols %in% colnames(md)))

  df <- md %>%
    rownames_to_column("cell") %>%
    mutate(.cluster = .data[[cluster_col_use]]) %>%
    select(cell, .cluster, all_of(sig_cols))

  cluster_means <- df %>%
    group_by(.cluster) %>%
    summarise(across(all_of(sig_cols), ~mean(.x, na.rm = TRUE)), .groups = "drop")

  out <- cluster_means %>%
    rowwise() %>%
    mutate(
      best_sig_col = sig_cols[which.max(c_across(all_of(sig_cols)))],
      best_sig     = gsub("^Sig_", "", best_sig_col),
      best_mean    = max(c_across(all_of(sig_cols)))
    ) %>%
    ungroup() %>%
    arrange(.cluster)

  out
}

# Nover prefix update:
# - Prefix with "NK_<label>__"
update_nover_prefix <- function(obj, label_col, nover_col = "Nover", prefix_tag = "NK") {
  stopifnot(label_col %in% colnames(obj[[]]))
  lab <- as.character(obj[[label_col]][,1])
  nk_prefix <- paste0(prefix_tag, "_", lab)

  md <- obj[[]]
  if (nover_col %in% colnames(md)) {
    old <- as.character(md[[nover_col]])
    old[is.na(old)] <- ""
    new_nover <- ifelse(nzchar(old), paste0(nk_prefix, "__", old), nk_prefix)
  } else {
    new_nover <- nk_prefix
  }

  obj[[nover_col]] <- new_nover
  log_msg("Updated meta.data$", nover_col, " with NK prefix from ", label_col)
  obj
}

# ----------------------------
# Start
# ----------------------------
log_msg("PRISM Step 3 (NKcell) starting")
log_msg("output_dir: ", opt$output_dir)
log_msg("work_dir: ", opt$work_dir)
log_msg("artifacts_dir: ", opt$artifacts_dir)
log_msg("cluster_col: ", opt$cluster_col)
log_msg("anno_col: ", opt$anno_col)

seurat_rds <- opt$seurat_rds %||% work_path("sce1_nonplasmacell_lineage_NKcell.rds")
require_file(seurat_rds, "--seurat-rds or <work-dir>/sce1_nonplasmacell_lineage_NKcell.rds")

log_msg("Loading Seurat object: ", seurat_rds)
obj <- readRDS(seurat_rds)
if (!inherits(obj, "Seurat")) stop("Loaded object is not a Seurat object: ", seurat_rds)

DefaultAssay(obj) <- "RNA"

# ----------------------------
# Standard Seurat workflow
# ----------------------------
log_msg("NormalizeData / FindVariableFeatures")
obj <- NormalizeData(obj, verbose = FALSE)
obj <- FindVariableFeatures(obj, verbose = FALSE)

log_msg("ScaleData / RunPCA")
obj <- ScaleData(obj, features = VariableFeatures(obj), verbose = FALSE)
obj <- RunPCA(obj, features = VariableFeatures(obj), verbose = FALSE)

dims_use <- seq_len(opt$dims)

log_msg("FindNeighbors / FindClusters / RunUMAP")
obj <- FindNeighbors(obj, dims = dims_use, reduction = "pca", verbose = FALSE)
obj <- FindClusters(obj, resolution = opt$resolution, cluster.name = opt$cluster_col, verbose = FALSE)
obj <- RunUMAP(obj, dims = dims_use, reduction = "pca", reduction.name = "umap", verbose = FALSE)

# ----------------------------
# Plots: UMAP
# ----------------------------
p_umap_clusters <- DimPlot_scCustom(obj, pt.size=0.6, reduction="umap", group.by=opt$cluster_col, label=TRUE)
save_plot_pdf(p_umap_clusters, "umap_clusters_NK", w=10, h=8)

if ("orig.ident" %in% colnames(obj[[]])) {
  p_umap_orig <- DimPlot_scCustom(obj, pt.size=0.6, reduction="umap", group.by="orig.ident", label=FALSE)
  save_plot_pdf(p_umap_orig, "umap_orig_ident_NK", w=10, h=8)
}

# ----------------------------
# Marker DotPlot
# ----------------------------
cols_vec <- colorRampPalette(c("steelblue", "white", "firebrick"))(26)
blue_red_palette <- colorRampPalette(c("steelblue", "white", "firebrick"))

allgene_present <- intersect(unique(allgene), rownames(obj))
if (length(allgene_present) > 0) {
  p_dot_default <- DotPlot(obj, features = allgene_present, cols = cols_vec, scale = TRUE) +
    RotatedAxis() + ggtitle("NK marker DotPlot (default order)")
  save_plot_pdf(p_dot_default, "dotplot_markers_default_NK", w=14, h=7)

  tryCatch({
    plot_data <- p_dot_default$data
    mat <- reshape2::dcast(plot_data, id ~ features.plot, value.var = "avg.exp.scaled")
    rownames(mat) <- mat$id
    mat$id <- NULL
    clust <- hclust(dist(mat))
    new_order <- clust$labels[clust$order]
    plot_data$id <- factor(plot_data$id, levels = new_order)

    p_dot_clustered <- ggplot(plot_data, aes(x = features.plot, y = id)) +
      geom_point(aes(size = pct.exp, fill = avg.exp.scaled), shape = 21, color = "black", stroke = 0) +
      scale_size(range = c(0, 8), name = "Percent Expressed") +
      scale_fill_gradientn(colors = blue_red_palette(100), name = "Average Expression") +
      theme_minimal() +
      theme(
        axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black")
      ) +
      labs(x = "Features", y = "Cluster", title = "NK marker DotPlot (cluster-reordered)")
    save_plot_pdf(p_dot_clustered, "dotplot_markers_clustered_NK", w=14, h=7)
  }, error = function(e) {
    log_msg("WARNING: clustered DotPlot reorder failed: ", conditionMessage(e))
  })
} else {
  log_msg("WARNING: No NK marker genes found in object; skipping DotPlot.")
}

# ----------------------------
# Signature scoring
# ----------------------------
log_msg("Computing signature scores (Sig_<name>)")
obj <- add_signature_scores(obj, ct_sigs, assay="RNA", slot="data")

# OPTIONAL: Example composite term (combination of two terms)
# If you want a composite "effector" state = cytotoxic + terminal:
# (Uncomment to enable)
# obj <- add_composite_signature(obj, new_name = "effector", weights_named_terms = c(cytotoxic = 1, terminal = 1))

# Use only Sig_* created in THIS run (prevents legacy Sig_ from appearing)
sig_cols <- attr(obj, "prism_sig_cols")
if (is.null(sig_cols) || length(sig_cols) == 0) stop("No prism_sig_cols attribute found; signature scoring likely failed.")
sig_cols <- sig_cols[sig_cols %in% colnames(obj[[]])]
if (length(sig_cols) == 0) stop("No Sig_* columns from this run exist in meta.data; cannot annotate/plot.")

# ----------------------------
# Per-cell annotation by best signature
# ----------------------------
obj <- annotate_cells_by_signature(
  obj,
  sig_cols = sig_cols,
  anno_col = opt$anno_col,
  min_score = opt$min_score,
  min_delta = opt$min_delta
)

p_umap_anno <- DimPlot_scCustom(obj, pt.size=0.6, reduction="umap", group.by=opt$anno_col, label=TRUE)
save_plot_pdf(p_umap_anno, "umap_signature_annotation_NK", w=12, h=8)

# FeaturePlot grid (non-empty due to print())
save_base_pdf({
  fp_list <- lapply(sig_cols, function(cc) FeaturePlot(obj, features = cc, reduction="umap") + ggtitle(cc))
  wrap_plots(fp_list, ncol = 3)
}, "featureplot_signature_scores_grid_NK", w=16, h=12)

# ----------------------------
# Update Nover for NK cells (robust):
# - Extract only 3 elements from existing Nover:
#     1) "NK cells"
#     2) CD56 sign: "CD56-" or "CD56+" (if absent -> "CD56?")
#     3) CD16 sign: "CD16+" or "CD16-" (if absent -> "CD16?")
# - Sanitize spaces -> underscores
# - Append new annotation suffix: "<NK_cells>_<CD56±>_<CD16±>_<newAnno>"
#
# Examples:
#   old Nover: "NK cells_CD56- CD16+ CD3"     + anno cytokine -> "NK_cells_CD56-_CD16+_cytokine"
#   old Nover: "NK cells CD56+ CD16- CD3"     + anno terminal -> "NK_cells_CD56+_CD16-_terminal"
# ----------------------------
update_nover_nk_compact <- function(obj, label_col, nover_col = "Nover",
                                    sep = "_",
                                    drop_new_prefix_regex = "^NK_",
                                    default_cd56 = "CD56?",
                                    default_cd16 = "CD16?") {
  stopifnot(label_col %in% colnames(obj[[]]))
  md <- obj[[]]
  if (!nover_col %in% colnames(md)) stop("meta.data column not found: ", nover_col)

  # new annotation (suffix)
  new_lab <- as.character(obj[[label_col]][,1])
  new_lab[is.na(new_lab)] <- ""
  new_lab <- gsub(drop_new_prefix_regex, "", new_lab)
  new_lab <- trimws(new_lab)

  old <- as.character(md[[nover_col]])
  old[is.na(old)] <- ""

  extract_one <- function(s) {
    if (!nzchar(s)) return(c("NK cells", default_cd56, default_cd16))

    # Normalize separators to spaces for easier regex
    s2 <- gsub("[_\\|;/]+", " ", s)

    # Always output NK cells as canonical text (not case-dependent)
    nk <- "NK cells"

    # CD56: capture sign if present
    m56 <- regmatches(s2, regexpr("CD56\\s*([\\+\\-])", s2, ignore.case = TRUE))
    cd56 <- if (length(m56) == 1 && nzchar(m56)) {
      # Normalize to "CD56+" or "CD56-"
      sign <- sub(".*([\\+\\-]).*", "\\1", m56)
      paste0("CD56", sign)
    } else {
      default_cd56
    }

    # CD16: capture sign if present
    m16 <- regmatches(s2, regexpr("CD16\\s*([\\+\\-])", s2, ignore.case = TRUE))
    cd16 <- if (length(m16) == 1 && nzchar(m16)) {
      sign <- sub(".*([\\+\\-]).*", "\\1", m16)
      paste0("CD16", sign)
    } else {
      default_cd16
    }

    c(nk, cd56, cd16)
  }

  parts <- t(vapply(old, extract_one, FUN.VALUE = character(3)))
  base3 <- paste(parts[,1], parts[,2], parts[,3], sep = sep)

  out <- ifelse(nzchar(new_lab),
                paste0(base3, sep, new_lab),
                base3)

  # sanitize spaces -> underscores, collapse repeats
  out <- gsub("[[:space:]]+", "_", out)
  out <- gsub("_+", "_", out)

  obj[[nover_col]] <- out
  log_msg("Updated meta.data$", nover_col, " to compact NK (CD56±/CD16±) + suffix from ", label_col)
  obj
}

# ----------------------------
# Apply
# ----------------------------
obj <- update_nover_nk_compact(
  obj,
  label_col = opt$anno_col,   # e.g., Annotation_NKcell ("cytokine"/"terminal"/...)
  nover_col = "Nover",
  sep = "_",
  drop_new_prefix_regex = "^NK_",
  default_cd56 = "CD56?",
  default_cd16 = "CD16?"
)

# Plot Nover on UMAP (sanity check)
p_umap_nover <- DimPlot_scCustom(obj, pt.size=0.6, reduction="umap", group.by="Nover", label=FALSE)
save_plot_pdf(p_umap_nover, "umap_Nover_NKcells_CD56_CD16_compact_plus_annotation", w=12, h=8)

# Optionally set Idents to Nover
Idents(obj) <- "Nover"

    

# ----------------------------
# Per-cluster predominant signature table (mean score)
# ----------------------------
pred_tbl <- predominant_signature_per_cluster(obj, cluster_col = opt$cluster_col, sig_cols = sig_cols)

anno_counts <- as.data.frame(table(obj[[opt$anno_col]][,1]))
colnames(anno_counts) <- c("label", "n_cells")
p_counts <- ggplot(anno_counts, aes(x = label, y = n_cells)) +
  geom_col() +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(x = opt$anno_col, y = "Cells", title = "NK annotation counts")
save_plot_pdf(p_counts, "annotation_counts_barplot_NK", w=10, h=6)

obj@meta.data$barcode<-rownames(obj@meta.data)
label<-obj@meta.data[,c('barcode','anno_col')]
write.csv(label,file=art_path('NKcell.noverlabel.csv'))
    
# ----------------------------
# Save final object
# ----------------------------
out_rds <- work_path("sce1_NKcell_annotated.rds")
saveRDS(obj, out_rds)
log_msg("Saved final Seurat object: ", out_rds)

log_msg("PRISM Step 3.5 finished successfully.")

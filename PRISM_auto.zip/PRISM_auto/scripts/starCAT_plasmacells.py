#!/usr/bin/env python3
"""
PRISM-style starCAT usage + cNMF-status annotation

Outputs (all under --outdir):
  - plots/        (PDFs)
  - tables/       (CSVs/TSVs)
  - anndata/      (updated .h5ad)
  - cache/        (starCAT cache, default)
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import numpy as np
import pandas as pd
import scanpy as sc
import matplotlib.pyplot as plt

from starcat import starCAT


# -----------------------------
# PRISM utilities
# -----------------------------
def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_name(s: str) -> str:
    s = str(s)
    s = "".join(ch if (ch.isalnum() or ch in "._-") else "_" for ch in s)
    while "__" in s:
        s = s.replace("__", "_")
    return s.strip("_")


def log_kv(title: str, kv: Dict[str, Any]) -> None:
    print(f"\n[{title}]")
    for k, v in kv.items():
        print(f"  - {k}: {v}")


def coerce_status_value(v: Any) -> float:
    """
    Robustly coerce status_map values to float.
    Accepts:
      - numeric types (int/float)
      - strings like "5", "GEP5", "gep_5", "status=5"
    Returns np.nan if cannot parse.
    """
    if v is None:
        return float("nan")
    if isinstance(v, (int, float, np.integer, np.floating)):
        return float(v)
    s = str(v).strip()
    # direct numeric
    try:
        return float(s)
    except Exception:
        pass
    # parse digits from strings like "GEP5"
    m = re.search(r"(\d+(\.\d+)?)", s)
    if m:
        try:
            return float(m.group(1))
        except Exception:
            return float("nan")
    return float("nan")


def choose_counts_matrix(adata: sc.AnnData, preferred_layer: str = "counts") -> Tuple[str, bool]:
    """
    Ensures adata.X is a non-negative matrix suitable for starCAT.
    Priority:
      1) adata.layers[preferred_layer] if present
      2) adata.raw.X if present
      3) adata.X as-is

    Returns:
      (source_label, is_integer_like)
    """
    source = "X"
    X = adata.X

    if preferred_layer and (preferred_layer in adata.layers):
        X = adata.layers[preferred_layer]
        adata.X = X
        source = f"layers['{preferred_layer}']"
    elif adata.raw is not None and adata.raw.X is not None:
        # NOTE: raw has its own var; but X shape should match obs x var of raw
        # For typical workflows raw shares obs and includes all genes.
        X = adata.raw.X
        adata.X = X
        source = "raw.X"

    # starCAT/NMF expects nonnegative
    try:
        # avoid densifying huge matrices; sample a few entries
        if hasattr(adata.X, "data"):
            # sparse
            min_val = float(np.min(adata.X.data)) if adata.X.data.size else 0.0
        else:
            min_val = float(np.nanmin(adata.X))
    except Exception:
        min_val = 0.0

    if min_val < 0:
        print(
            f"\n[WARN] Detected negative values in {source} (min={min_val}). "
            "This is not suitable for NMF-based fitting. "
            "If this came from scaled data, switch to raw counts. "
            "Proceeding by clipping negatives to 0 (stopgap)."
        )
        # Clip safely for sparse / dense
        if hasattr(adata.X, "data"):
            adata.X.data = np.maximum(adata.X.data, 0)
        else:
            adata.X = np.maximum(adata.X, 0)

    # integer-like check (for warning hygiene)
    is_int_like = False
    try:
        if hasattr(adata.X, "data"):
            vals = adata.X.data
        else:
            vals = np.ravel(adata.X)
        if vals.size:
            samp = vals[: min(vals.size, 2000)]
            # allow tiny float noise
            is_int_like = bool(np.all(np.isfinite(samp)) and np.all(np.abs(samp - np.round(samp)) < 1e-6))
        else:
            is_int_like = True
    except Exception:
        is_int_like = False

    return source, is_int_like


@dataclass
class PRISMPaths:
    outdir: Path
    plots_dir: Path
    tables_dir: Path
    anndata_dir: Path
    cache_dir: Path

    @staticmethod
    def build(outdir: str, cache_dir: Optional[str]) -> "PRISMPaths":
        """
        Enforce PRISM convention: plots/tables/anndata/cache all live under outdir (work dir),
        unless cache_dir is an absolute path explicitly provided.
        """
        outdir_p = ensure_dir(Path(outdir).resolve())

        # Cache dir policy:
        # - If cache_dir is None: outdir/cache
        # - If cache_dir is relative: outdir/<cache_dir>
        # - If cache_dir is absolute: use it
        if cache_dir is None:
            cache_p = outdir_p / "cache"
        else:
            cache_candidate = Path(cache_dir)
            cache_p = cache_candidate if cache_candidate.is_absolute() else (outdir_p / cache_candidate)

        return PRISMPaths(
            outdir=outdir_p,
            plots_dir=ensure_dir(outdir_p / "plots"),
            tables_dir=ensure_dir(outdir_p / "tables"),
            anndata_dir=ensure_dir(outdir_p / "anndata"),
            cache_dir=ensure_dir(cache_p),
        )

    def plot_pdf_path(self, name: str) -> Path:
        n = safe_name(name)
        return self.plots_dir / f"{n}.pdf"
    
    def table_path(self, name: str, suffix: str = ".csv") -> Path:
        n = safe_name(name)
        return self.tables_dir / f"{n}{suffix}"
    
    def anndata_path(self, name: str) -> Path:
        n = safe_name(name)
        return self.anndata_dir / f"{n}.h5ad"



# -----------------------------
# Core PRISM steps
# -----------------------------
def run_starcat(adata: sc.AnnData, starcat_ref: str, cache_dir: Path) -> pd.DataFrame:
    """
    Returns usage dataframe indexed by adata.obs_names
    """
    tcat = starCAT(reference=starcat_ref, cachedir=str(cache_dir))
    usage, _ = tcat.fit_transform(adata)

    if not usage.index.equals(adata.obs_names):
        usage = usage.reindex(adata.obs_names)

    return usage


def merge_usage_into_obs(adata: sc.AnnData, usage: pd.DataFrame) -> None:
    for col in usage.columns:
        adata.obs[col] = pd.to_numeric(usage[col], errors="coerce")


def compute_cnmf_status(
    adata: sc.AnnData,
    use_cols: List[str],
    status_map: Dict[str, Any],
    conf_threshold: Optional[float] = None,
) -> Tuple[pd.Series, pd.Series, pd.Categorical]:
    present = [c for c in use_cols if c in adata.obs.columns]
    if len(present) == 0:
        raise ValueError(
            "None of the requested CNMF usage columns are present in adata.obs. "
            f"Requested: {use_cols}"
        )

    U = adata.obs[present].apply(pd.to_numeric, errors="coerce").astype(float)
    vals_mat = U.to_numpy()

    status: List[float] = []
    confidence: List[float] = []

    for r in range(vals_mat.shape[0]):
        vals = vals_mat[r, :]
        if np.all(~np.isfinite(vals)):
            status.append(np.nan)
            confidence.append(np.nan)
            continue

        s = np.nansum(vals)
        m = np.nanmax(vals)
        j = int(np.nanargmax(vals))
        chosen_col = present[j]

        mapped = status_map.get(chosen_col, chosen_col)
        status.append(coerce_status_value(mapped))

        conf = (m / s) if (np.isfinite(m) and np.isfinite(s) and s > 0) else np.nan
        confidence.append(conf)

    status_s = pd.Series(status, index=U.index, dtype="Float64")
    conf_s = pd.Series(confidence, index=U.index, dtype="Float64")

    if conf_threshold is not None:
        low = conf_s.fillna(0) < float(conf_threshold)
        status_s.loc[low] = pd.NA

    cat = (
        status_s.astype("Int64")
        .astype(str)
        .replace({"<NA>": "NA"})
        .astype("category")
    )

    return status_s, conf_s, cat


def plot_umap_to_pdf(
    adata: sc.AnnData,
    colors: List[str],
    pdf_path: Path,
    ncols: int = 4,
    vmin: Optional[float] = 0,
    vmax: Optional[str] = "p99",
    size: float = 8,
    cmap: Optional[str] = "turbo",
    title: Optional[str] = None,
) -> None:
    sc.pl.umap(
        adata,
        color=colors,
        ncols=ncols,
        vmin=vmin,
        vmax=vmax,
        size=size,
        color_map=cmap,
        show=False,
        wspace=0.3,
    )
    if title:
        plt.suptitle(title, y=1.02)

    plt.savefig(pdf_path, bbox_inches="tight")
    plt.close()


# -----------------------------
# CLI
# -----------------------------
def build_argparser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="PRISM: starCAT usage + cNMF status annotation")
    p.add_argument("--h5ad", required=True, help="Input AnnData .h5ad (counts or processed)")
    p.add_argument("--starcat-ref", required=True, help="starCAT reference spectra file (.txt)")
    p.add_argument("--outdir", required=True, help="Work directory (all outputs go under here)")
    p.add_argument(
        "--cache-dir",
        default=None,
        help="Cache directory. If relative, it will be placed under --outdir. Default: --outdir/cache",
    )
    
    p.add_argument(
        "--counts-layer",
        default="counts",
        help="Preferred AnnData layer to use as counts matrix (default: 'counts'). "
             "If not present, script will try adata.raw.X, then adata.X.",
    )

    p.add_argument(
        "--use-cols",
        nargs="+",
        default=["GEP1", "GEP2", "GEP3", "GEP4", "GEP5", "GEP6", "GEP7", "GEP8", "GEP9", "GEP11"],
        help="Usage columns to consider for cnmf_status assignment",
    )

    # IMPORTANT: default now maps to numeric labels
    p.add_argument(
        "--status-map",
        default='{"GEP1":1, "GEP2":2, "GEP3":3, "GEP4":4, "GEP5":5, "GEP6":6, "GEP7":7, "GEP8":8, "GEP9":9, "GEP11":11}',
        help="JSON mapping from usage column -> numeric status label",
    )

    p.add_argument(
        "--conf-threshold",
        type=float,
        default=None,
        help="If set, cells with cnmf_status_confidence < threshold are set to NA",
    )

    p.add_argument(
        "--plot-all-usage",
        action="store_true",
        help="If set, plot all starCAT usage columns (can be large). Default: plot only --use-cols.",
    )

    return p


def main() -> None:
    args = build_argparser().parse_args()
    paths = PRISMPaths.build(args.outdir, args.cache_dir)

    status_map = json.loads(args.status_map)
    if not isinstance(status_map, dict):
        raise ValueError("--status-map must decode to a JSON object (dict).")

    log_kv(
        "Inputs",
        {
            "h5ad": args.h5ad,
            "starcat_ref": args.starcat_ref,
            "outdir": str(paths.outdir),
            "plots_dir": str(paths.plots_dir),
            "tables_dir": str(paths.tables_dir),
            "anndata_dir": str(paths.anndata_dir),
            "cache_dir": str(paths.cache_dir),
            "counts_layer": args.counts_layer,
        },
    )

    # 1) Load
    adata = sc.read_h5ad(args.h5ad)
    log_kv("AnnData", {"n_obs": adata.n_obs, "n_vars": adata.n_vars})

    # 1b) Ensure UMAP exists for plotting
    if "X_umap" not in adata.obsm_keys():
        raise ValueError("adata.obsm['X_umap'] not found. Compute UMAP first (sc.tl.umap) before running this script.")

    # 1c) Prefer counts for starCAT
    source, is_int_like = choose_counts_matrix(adata, preferred_layer=args.counts_layer)
    if not is_int_like:
        print(
            f"\n[WARN] starCAT expects integer counts; using {source} which does not look integer-like. "
            "If you have raw counts, store them in adata.layers['counts'] and rerun."
        )
    else:
        print(f"\n[OK] Using {source} as query matrix for starCAT (looks integer-like).")

    # 2) starCAT usage
    usage = run_starcat(adata, args.starcat_ref, paths.cache_dir)
    merge_usage_into_obs(adata, usage)

    # 3) Plot usage UMAP
    usage_cols = sorted(list(usage.columns)) if args.plot_all_usage else [c for c in args.use_cols if c in adata.obs.columns]
    if len(usage_cols) > 0:
        pdf = paths.plot_pdf_path("umap_starcat_usage")
        plot_umap_to_pdf(
            adata,
            colors=usage_cols,
            pdf_path=pdf,
            ncols=4,
            vmin=0,
            vmax="p99",
            size=8,
            cmap="turbo",
            title="starCAT usage (selected columns)" if not args.plot_all_usage else "starCAT usage (all columns)",
        )
        print(f"Wrote: {pdf}")

    # 4) cNMF status assignment
    status_s, conf_s, cat = compute_cnmf_status(
        adata=adata,
        use_cols=args.use_cols,
        status_map=status_map,
        conf_threshold=args.conf_threshold,
    )
    adata.obs["cnmf_status"] = status_s
    adata.obs["cnmf_status_confidence"] = conf_s
    adata.obs["cnmf_status_cat"] = cat

    print(
        "\nAssigned cnmf_status to "
        f"{adata.obs['cnmf_status'].notna().sum()} / {adata.n_obs} cells.\n"
        "Value counts:\n",
        adata.obs["cnmf_status_cat"].value_counts(dropna=False),
    )

    # 5) Plot cnmf_status
    pdf = paths.plot_pdf_path("umap_cnmf_status")
    sc.pl.umap(
        adata,
        color=["cnmf_status_cat"],
        show=False,
        legend_loc="right margin",
        legend_fontsize=8,
        size=8,
        wspace=0.3,
    )
    plt.savefig(pdf, bbox_inches="tight")
    plt.close()
    print(f"Wrote: {pdf}")

    # 6) Save usage table (selected columns)
    present_cols = [c for c in args.use_cols if c in adata.obs.columns]
    usage_norm = adata.obs[present_cols].copy()
    csv_path = paths.table_path("plasmacellsignature", suffix=".csv")
    usage_norm.to_csv(csv_path, index=True)
    print(f"Wrote: {csv_path}")

    log_kv(
        "PRISM R step 2.1 finished successfully.",
        {
            "plots_dir": str(paths.plots_dir),
            "tables_dir": str(paths.tables_dir),
            "anndata_dir": str(paths.anndata_dir),
            "cache_dir": str(paths.cache_dir),
        },
    )


if __name__ == "__main__":
    main()

#!/usr/bin/env Rscript

# ============================
# PRISM standard CLI header (R) — PATCHED FULL SCRIPT
# ============================
# Set these *before* library(reticulate) or library(sceasy)
Sys.setenv(RETICULATE_PYTHON = "/lab-share/Cardio-Pu-e2/Public/ch257181_sunny/miniconda3/envs/carlin/bin/python")
options(reticulate.conda_binary = "/lab-share/Cardio-Pu-e2/Public/ch257181_sunny/miniconda3/bin/conda")

library(reticulate)
py_config()  # should now show your conda 'jupyter' Python


suppressPackageStartupMessages({
  library(optparse)
  library(Seurat)
  library(patchwork)
  library(speckle)
  library(limma)
  library(ggplot2)
  library(DoubletFinder)
  library(SoupX)
  library(DropletUtils)
  library(Matrix)
  library(celda)
  library(SingleCellExperiment)
  library(reticulate)
  library(scCustomize)
  library(scDblFinder)
  library(BiocParallel)
  library(dplyr)
  library(tibble)
})
set.seed(123)

# ----------------------------
# CLI options
# ----------------------------
option_list <- list(
  make_option(c("--h5ad"), type="character", default=NA_character_,
              help="Path to input .h5ad (used by step 1; others may ignore)"),
  make_option(c("--metadata"), type="character", default=NA_character_,
              help="Path to metadata CSV (often required)"),
  make_option(c("--output-dir"), type="character", default=".",
              help="Task output directory (root for logs/work/artifacts)"),
  make_option(c("--work-dir"), type="character", default=NA_character_,
              help="Working directory for intermediates (default: <output-dir>/work)"),
  make_option(c("--artifacts-dir"), type="character", default=NA_character_,
              help="Directory for final artifacts (default: <output-dir>/artifacts)"),
  make_option(c("--task-id"), type="integer", default=NA_integer_,
              help="Task ID (for logging/UI)"),
  make_option(c("--step-id"), type="character", default=NA_character_,
              help="Step ID like 1, 2.1, 3.2, 4.1 (for logging/UI)")
)

opt <- parse_args(OptionParser(option_list = option_list))

# ----------------------------
# Helpers: robust option handling + logging + paths + metadata alignment
# ----------------------------
is_unset <- function(x) is.null(x) || length(x) == 0 || all(is.na(x)) || !nzchar(as.character(x)[1])

# ---- Logging helpers ----
log_msg <- function(...) {
  ts <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  cat(sprintf("[%s][task=%s][step=%s] ", ts, opt$task_id, opt$step_id),
      paste0(..., collapse=""), "\n")
}


# ---- Resolve defaults (ROBUST) ----

if (is_unset(opt$output_dir)) opt$output_dir <- "."
if (is_unset(opt$work_dir)) opt$work_dir <- file.path(opt$output_dir, "work")
if (is_unset(opt$artifacts_dir)) opt$artifacts_dir <- file.path(opt$output_dir, "artifacts")

dir.create(opt$output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$work_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$artifacts_dir, recursive = TRUE, showWarnings = FALSE)

work_path <- function(...) file.path(opt$work_dir, ...)
art_path  <- function(...) file.path(opt$artifacts_dir, ...)

# ---- File check helper ----
require_file <- function(path, label) {
  if (is_unset(path)) stop(sprintf("Missing required input: %s", label))
  if (!file.exists(path)) stop(sprintf("File not found for %s: %s", label, path))
}

# ---- Metadata loader that aligns rows to Seurat cell barcodes ----
read_and_align_metadata <- function(csv_path, obj, barcode_col = NULL) {
  require_file(csv_path, "--metadata")
  md <- read.csv(csv_path, stringsAsFactors = FALSE, check.names = FALSE)

  # Determine barcode vector and strip barcode column from metadata frame
  if (!is.null(barcode_col) && barcode_col %in% colnames(md)) {
    bc <- md[[barcode_col]]
    md[[barcode_col]] <- NULL
  } else {
    candidates <- c("barcode","Barcode","cell","Cell","cell_id","cellid","CellID")
    hit <- candidates[candidates %in% colnames(md)]
    if (length(hit) > 0) {
      bc <- md[[hit[1]]]
      md[[hit[1]]] <- NULL
    } else {
      # fall back to first column
      bc <- md[[1]]
      md <- md[, -1, drop = FALSE]
    }
  }

  bc <- as.character(bc)
  rownames(md) <- bc

  cells <- colnames(obj)
  if (!all(cells %in% rownames(md))) {
    missing <- setdiff(cells, rownames(md))
    stop(sprintf("Metadata missing %d / %d cells. Example missing: %s",
                 length(missing), length(cells), paste(head(missing, 5), collapse = ", ")))
  }

  md <- md[cells, , drop = FALSE]  # reorder
  md
}

# ---- Plot path helper ----
plots_dir <- file.path(opt$artifacts_dir, "plots_step1")
dir.create(plots_dir, recursive = TRUE, showWarnings = FALSE)

plot_pdf_path <- function(name) {
  safe <- gsub("[[:space:]]+", "_", name)
  safe <- gsub("[^A-Za-z0-9_\\-\\.]", "", safe)
  file.path(plots_dir, paste0(safe, ".pdf"))
}

# ----------------------------
# Start logs
# ----------------------------
log_msg("PRISM R step starting")
log_msg("h5ad: ", opt$h5ad)
log_msg("metadata: ", opt$metadata)
log_msg("output_dir: ", opt$output_dir)
log_msg("work_dir: ", opt$work_dir)
log_msg("artifacts_dir: ", opt$artifacts_dir)

# ----------------------------
# Step 1: Convert h5ad -> Seurat, join layers, attach metadata
# ----------------------------
require_file(opt$h5ad, "--h5ad")
sceasy::convertFormat(opt$h5ad, from = "anndata", to = "seurat",
                      outFile = work_path("sce1_input.rds"))

sce1 <- readRDS(work_path("sce1_input.rds"))
#sce1 <- JoinLayers(sce1)
DefaultAssay(sce1) <- "RNA"

# Attach metadata (aligned to cells)
md_aligned <- read_and_align_metadata(opt$metadata, sce1)
sce1@meta.data <- md_aligned
stopifnot(identical(rownames(sce1@meta.data), colnames(sce1)))

# ----------------------------
# QC plots
# ----------------------------
sce1[["percent.mt"]] <- PercentageFeatureSet(sce1, pattern = "^MT-")
sce1[["percent.ig"]] <- PercentageFeatureSet(sce1, pattern = "^IG")
sce1[["percent.hb"]] <- PercentageFeatureSet(sce1, pattern = "^HB")

pdf_file <- plot_pdf_path("quality_control")
pdf(pdf_file, width = 15, height = 7)
VlnPlot(sce1, features = c("nFeature_RNA", "nCount_RNA"), ncol = 2)
qc_feats <- c("percent.mt", "percent.ig", "percent.hb")
qc_feats_present <- qc_feats[qc_feats %in% colnames(sce1@meta.data)]
if (length(qc_feats_present) > 0) {
  VlnPlot(sce1, features = qc_feats_present, ncol = length(qc_feats_present))
} else {
  plot.new(); title("QC: percent.mt/percent.ig/percent.hb not found in metadata")
}
dev.off()
log_msg("Saved plot: ", pdf_file)

# ----------------------------
# Standard analysis workflow (pre-clean)
# ----------------------------
sce1 <- NormalizeData(sce1)
sce1 <- FindVariableFeatures(sce1)
sce1 <- ScaleData(sce1)
sce1 <- RunPCA(sce1)

# ----------------------------
# Ambient RNA removal: DecontX
# ----------------------------
sce <- sceasy::convertFormat(sce1, from = "seurat", to = "sce")
sce_decontX <- decontX(sce)
decontaminated_counts <- assay(sce_decontX, "decontXcounts")

sce1_clean <- CreateSeuratObject(counts = decontaminated_counts)
sce1_clean@meta.data <- sce1@meta.data
sce1 <- sce1_clean

# ----------------------------
# Standard analysis workflow (post-clean)
# ----------------------------
sce1 <- NormalizeData(sce1)
sce1 <- FindVariableFeatures(sce1)
sce1 <- ScaleData(sce1)
sce1 <- RunPCA(sce1)
sce1 <- FindNeighbors(sce1, dims = 1:15, reduction = "pca")
sce1 <- FindClusters(sce1, resolution = 1, cluster.name = "seurat_clusters")
sce1 <- RunUMAP(sce1, dims = 1:15, reduction = "pca", reduction.name = "UMAP")

# Plot clusters
out_pdf <- plot_pdf_path("umap_seurat_clusters")
p <- DimPlot_scCustom(sce1, pt.size = 1, reduction = "UMAP",
                      group.by = "seurat_clusters", label = TRUE)
ggsave(filename = out_pdf, plot = p, width = 10, height = 8)
log_msg("Saved plot: ", out_pdf)

# Plot orig.ident if present
if ("orig.ident" %in% colnames(sce1@meta.data)) {
  out_pdf <- plot_pdf_path("umap_orig_ident")
  p <- DimPlot_scCustom(sce1, pt.size = 1, reduction = "UMAP",
                        group.by = "orig.ident", label = TRUE)
  ggsave(filename = out_pdf, plot = p, width = 10, height = 8)
  log_msg("Saved plot: ", out_pdf)
} else {
  log_msg("Skipping orig.ident UMAP: column 'orig.ident' not found in metadata.")
}

# Feature QC plot (only features available)
feat_list <- c("nFeature_RNA", "nCount_RNA", "percent.mt", "percent.ig", "percent.hb")
feat_list_present <- feat_list[feat_list %in% c(rownames(sce1), colnames(sce1@meta.data))]
out_pdf <- plot_pdf_path("umap_quality_control")
p <- FeaturePlot(sce1, pt.size = 1, reduction = "UMAP", features = feat_list_present)
ggsave(filename = out_pdf, plot = p, width = 15, height = 20)
log_msg("Saved plot: ", out_pdf)

# ----------------------------
# Doublet removal: scDblFinder
# ----------------------------
sce <- sceasy::convertFormat(sce1, from="seurat", to="sce")
sce_dbl <- scDblFinder(sce, samples = if ("orig.ident" %in% colnames(colData(sce))) "orig.ident" else NULL,
                       BPPARAM = MulticoreParam(1))

dbl <- data.frame(
  barcode = colnames(sce_dbl),
  singlet = as.character(sce_dbl$scDblFinder.class),
  stringsAsFactors = FALSE
)
rownames(dbl) <- dbl$barcode
dbl$barcode <- NULL

# join by cell names (safe)
sce1@meta.data <- cbind(sce1@meta.data, dbl[colnames(sce1), , drop = FALSE])

# keep singlets
sce1 <- subset(sce1, subset = singlet == "singlet")

# ----------------------------
# Standard workflow after singlet filter
# ----------------------------
sce1 <- NormalizeData(sce1)
sce1 <- FindVariableFeatures(sce1)
sce1 <- ScaleData(sce1)
sce1 <- RunPCA(sce1)
sce1 <- FindNeighbors(sce1, dims = 1:15, reduction = "pca")
sce1 <- FindClusters(sce1, resolution = 1, cluster.name = "seurat_clusters")
sce1 <- RunUMAP(sce1, dims = 1:15, reduction = "pca", reduction.name = "UMAP")

# QC plot post-singlet
feat_list_present <- feat_list[feat_list %in% c(rownames(sce1), colnames(sce1@meta.data))]
out_pdf <- plot_pdf_path("umap_quality_control_singlet")
p <- FeaturePlot(sce1, pt.size = 1, reduction = "UMAP", features = feat_list_present)
ggsave(filename = out_pdf, plot = p, width = 15, height = 20)
log_msg("Saved plot: ", out_pdf)

# orig.ident post-singlet
if ("orig.ident" %in% colnames(sce1@meta.data)) {
  out_pdf <- plot_pdf_path("umap_orig_ident_singlet")
  p <- DimPlot_scCustom(sce1, pt.size = 1, reduction = "UMAP",
                        group.by = "orig.ident", label = TRUE)
  ggsave(filename = out_pdf, plot = p, width = 10, height = 8)
  log_msg("Saved plot: ", out_pdf)
}

# seurat_clusters post-singlet
out_pdf <- plot_pdf_path("umap_seurat_clusters_singlet")
p <- DimPlot_scCustom(sce1, pt.size = 1, reduction = "UMAP",group.by = "seurat_clusters", label = TRUE)
ggsave(filename = out_pdf, plot = p, width = 10, height = 8)
log_msg("Saved plot: ", out_pdf)


# marker genes post-singlet
marker_genes <- c("CD38","SDC1","XBP1","PRDM1","SLAMF7","TNFRSF17")
marker_present <- marker_genes[marker_genes %in% rownames(sce1)]
if (length(marker_present) > 0) {
  out_pdf <- plot_pdf_path("umap_marker_gene_singlet")
  p <- FeaturePlot(sce1, pt.size = 1, reduction = "UMAP", features = marker_present)
  ggsave(filename = out_pdf, plot = p, width = 15, height = 20)
  log_msg("Saved plot: ", out_pdf)
} else {
  log_msg("Skipping marker FeaturePlot: none of CD38/SDC1/XBP1/PRDM1/SLAMF7/TNFRSF17 present in assay features.")
}


# ----------------------------
# PlasmaCell vs NonPlasmaCell assignment (SEPARATE metrics + 2D scoring)
# ----------------------------
obj <- sce1

cluster_col <- "seurat_clusters"     # cluster assignment produced earlier
label_col   <- "seurat_clusters"     # overwrite to PlasmaCell / NonPlasmaCell

# Separate score columns (per-cell)
score_gene_col <- "Sig_PlasmaCell_Genes"
score_ig_col   <- "Sig_PlasmaCell_percentIG"

stopifnot(cluster_col %in% colnames(obj[[]]))

# ---- Signature genes (NO percent.ig inside) ----
plasma_genes <- c("CD38","SDC1","XBP1","PRDM1","SLAMF7","TNFRSF17")

assay_use <- DefaultAssay(obj)
expr <- GetAssayData(obj, assay = assay_use, slot = "data")

genes_present <- intersect(plasma_genes, rownames(expr))
if (length(genes_present) == 0) stop("None of the PlasmaCell genes found in the assay features.")

# 1) Per-cell gene signature score (mean expression over genes)
gene_score <- Matrix::colMeans(expr[genes_present, , drop = FALSE])
gene_score <- as.numeric(gene_score)
names(gene_score) <- colnames(obj)
obj[[score_gene_col]] <- gene_score

# 2) Per-cell percent.ig (kept separate; use metadata as-is)
if (!("percent.ig" %in% colnames(obj@meta.data))) {
  stop("Metadata column 'percent.ig' not found; cannot compute separate IG score.")
}
ig_score <- as.numeric(obj@meta.data[["percent.ig"]])
names(ig_score) <- rownames(obj@meta.data)
# align to object columns
ig_score <- ig_score[colnames(obj)]
obj[[score_ig_col]] <- ig_score

# ----------------------------
# Aggregate per cluster (means)
# ----------------------------
df2 <- obj@meta.data %>%
  rownames_to_column("cell") %>%
  transmute(
    cell,
    .cluster = .data[[cluster_col]],
    .gene    = .data[[score_gene_col]],
    .ig      = .data[[score_ig_col]]
  )

cluster_scores <- df2 %>%
  group_by(.cluster) %>%
  summarise(
    .n = dplyr::n(),
    gene_mean = mean(.gene, na.rm = TRUE),
    ig_mean   = mean(.ig,   na.rm = TRUE),
    .groups = "drop"
  )

# ----------------------------
# Cluster classification
# Option A (recommended): 2D kmeans on (gene_mean, ig_mean)
# ----------------------------
km2 <- kmeans(cluster_scores[, c("gene_mean","ig_mean")], centers = 2)

cluster_scores$.km_group <- km2$cluster

# Identify which kmeans group is "PlasmaCell":
# choose the group with higher gene_mean; tie-breaker by ig_mean
grp_summary <- cluster_scores %>%
  group_by(.km_group) %>%
  summarise(
    gm = mean(gene_mean, na.rm = TRUE),
    im = mean(ig_mean,   na.rm = TRUE),
    .groups = "drop"
  ) %>%
  arrange(desc(gm), desc(im))

plasma_group <- grp_summary$.km_group[1]

cluster_scores$.label <- ifelse(cluster_scores$.km_group == plasma_group,
                                "PlasmaCell", "NonPlasmaCell")

cluster_to_label <- setNames(cluster_scores$.label, cluster_scores$.cluster)

# ----------------------------
# (Optional safety net): force PlasmaCell if gene_mean is extreme-high even if kmeans says no
# This catches rare cases where kmeans boundary is weird.
# Uncomment if needed.
# ----------------------------
# gene_thr <- quantile(cluster_scores$gene_mean, 0.80, na.rm = TRUE)
# ig_thr   <- quantile(cluster_scores$ig_mean,   0.80, na.rm = TRUE)
# force_plasma <- (cluster_scores$gene_mean >= gene_thr) | (cluster_scores$ig_mean >= ig_thr)
# cluster_scores$.label[force_plasma] <- "PlasmaCell"
# cluster_to_label <- setNames(cluster_scores$.label, cluster_scores$.cluster)

# ----------------------------
# Apply to cells (overwrite seurat_clusters labels)
# ----------------------------
new_labels <- cluster_to_label[as.character(obj@meta.data[[cluster_col]])]
stopifnot(length(new_labels) == nrow(obj@meta.data))

obj@meta.data[[label_col]] <- unname(new_labels)
Idents(obj) <- obj@meta.data[[label_col]]

# seurat_clusters post-singlet
out_pdf <- plot_pdf_path("umap_seurat_clusters_binary")
p <- DimPlot_scCustom(obj, pt.size = 1, reduction = "UMAP",group.by = "seurat_clusters", label = TRUE)
ggsave(filename = out_pdf, plot = p, width = 10, height = 8)
log_msg("Saved plot: ", out_pdf)


# Split objects
sce1 <- obj
sce1_plasmacell    <- subset(sce1, subset = seurat_clusters == "PlasmaCell")
sce1_nonplasmacell <- subset(sce1, subset = seurat_clusters == "NonPlasmaCell")

# Save outputs (work directory)
saveRDS(sce1,               file = work_path("sce1_output.rds"))
saveRDS(sce1_plasmacell,    file = work_path("sce1_plasmacell.rds"))
saveRDS(sce1_nonplasmacell, file = work_path("sce1_nonplasmacell.rds"))                       

log_msg("Saved RDS: ", work_path("sce1_output.rds"))
log_msg("Saved RDS: ", work_path("sce1_plasmacell.rds"))
log_msg("Saved RDS: ", work_path("sce1_nonplasmacell.rds"))

sce1_plasmacell[["RNA"]] <- as(sce1_plasmacell[["RNA"]], "Assay")
log_msg("Exporting to h5ad via sceasy: ", work_path("sce1_plasmacell.h5ad"))
sceasy::convertFormat(sce1_plasmacell, from = "seurat", to = "anndata", outFile = work_path("sce1_plasmacell.h5ad"))
log_msg("Saved h5ad: ", work_path("sce1_plasmacell.h5ad"))


cat("\nCell counts:\n")
print(table(sce1$seurat_clusters, useNA = "ifany"))

cat("\nCluster score table (cluster-level means):\n")
print(cluster_scores %>% arrange(desc(gene_mean), desc(ig_mean)))

log_msg("PRISM step 1 complete.")

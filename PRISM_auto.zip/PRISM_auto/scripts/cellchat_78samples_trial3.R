#!/usr/bin/env Rscript

# ============================
# PRISM standard CLI header (R) — STREAMLINED
#   - All plots/tables routed via art_path()
#   - Reduced deps + de-duplicated logic
#   - Avoids hard-coded output folders
# ============================

# IMPORTANT: set reticulate *before* library(reticulate)
Sys.setenv(RETICULATE_PYTHON = "/lab-share/Cardio-Pu-e2/Public/ch257181_sunny/miniconda3/envs/carlin/bin/python")
options(reticulate.conda_binary = "/lab-share/Cardio-Pu-e2/Public/ch257181_sunny/miniconda3/bin/conda")

suppressPackageStartupMessages({
  library(optparse)
  library(reticulate)

  library(Seurat)
  library(scCustomize)
  library(CellChat)
  library(Matrix)

  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(readr)
  library(ggplot2)
  library(forcats)
})

set.seed(123)

# ----------------------------
# CLI options
# ----------------------------
option_list <- list(
  make_option(c("--h5ad"), type="character", default=NA_character_,
              help="(Unused in this step) Path to input .h5ad"),
  make_option(c("--metadata"), type="character", default=NA_character_,
              help="(Unused in this step) Path to metadata CSV"),
  make_option(c("--output-dir"), type="character", default=".",
              help="Task output directory (root for work/artifacts)"),
  make_option(c("--work-dir"), type="character", default=NA_character_,
              help="Working directory (default: <output-dir>/work)"),
  make_option(c("--artifacts-dir"), type="character", default=NA_character_,
              help="Artifacts directory (default: <output-dir>/artifacts)"),
  make_option(c("--task-id"), type="integer", default=NA_integer_,
              help="Task ID (for logging/UI)"),
  make_option(c("--step-id"), type="character", default=NA_character_,
              help="Step ID like 1, 2.1, 3.2, 4.1 (for logging/UI)"),

  # Inputs used in THIS script
  make_option(c("--seurat-rds"), type="character", default=NA_character_,
              help="Path to input Seurat .rds (default: <work-dir>/sce1_output.rds)"),

  # CellChat settings
  make_option(c("--species"), type="character", default="human",
              help="CellChat DB species: 'human' or 'mouse' (default: human)"),
  make_option(c("--group-col"), type="character", default="Nover",
              help="Cell type column in meta.data for CellChat groups (default: Nover)"),
  make_option(c("--sample-col"), type="character", default="orig.ident",
              help="Sample column to iterate over (default: orig.ident)"),
  make_option(c("--expr-prop"), type="double", default=0.05,
              help="thresh.pc for identifyOverExpressedGenes (0-1) (default: 0.05)"),
  make_option(c("--min-cells"), type="integer", default=10,
              help="min.cells for filterCommunication (default: 10)"),
  make_option(c("--top-k-pathways"), type="integer", default=20,
              help="Top-K pathways per sample for summary/detail exports and dotplots (default: 20)"),
  make_option(c("--min-prob-show"), type="double", default=0,
              help="Minimum prob to show in dotplots (default: 0)")
)

opt <- parse_args(OptionParser(option_list = option_list))

# ----------------------------
# Helpers: robust option
# ----------------------------
is_unset <- function(x) is.null(x) || length(x) == 0 || all(is.na(x)) || !nzchar(as.character(x)[1])
`%||%` <- function(a, b) if (!is_unset(a)) a else b

# ---- Logging ----
log_msg <- function(...) {
  ts <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  cat(sprintf("[%s][task=%s][step=%s] ", ts, opt$task_id, opt$step_id),
      paste0(..., collapse=""), "\n")
}

# ---- Resolve defaults ----
opt$output_dir    <- opt$output_dir %||% "."
opt$work_dir      <- opt$work_dir %||% file.path(opt$output_dir, "work")
opt$artifacts_dir <- opt$artifacts_dir %||% file.path(opt$output_dir, "artifacts")

dir.create(opt$output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$work_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$artifacts_dir, recursive = TRUE, showWarnings = FALSE)

work_path <- function(...) file.path(opt$work_dir, ...)
art_path  <- function(...) file.path(opt$artifacts_dir, ...)

require_file <- function(path, label) {
  if (is_unset(path)) stop(sprintf("Missing required input: %s", label))
  if (!file.exists(path)) stop(sprintf("File not found for %s: %s", label, path))
}

# ---- Artifacts subdirs (PRISM) ----
dir_plots_step4   <- art_path("plots_step4")
dir_tables_step4  <- art_path("tables")
dir_dotplots      <- art_path("plots_step4", "cellchat_dotplots")

dir.create(dir_plots_step4,  recursive = TRUE, showWarnings = FALSE)
dir.create(dir_tables_step4, recursive = TRUE, showWarnings = FALSE)
dir.create(dir_dotplots,     recursive = TRUE, showWarnings = FALSE)

safe_name <- function(x) {
  x <- gsub("[[:space:]]+", "_", x)
  x <- gsub("[^A-Za-z0-9_\\-\\.]", "", x)
  x
}

plot_pdf_path <- function(name) file.path(dir_plots_step4, paste0(safe_name(name), ".pdf"))
dotplot_pdf_path <- function(name) file.path(dir_dotplots, paste0(safe_name(name), ".pdf"))
table_csv_path <- function(name) file.path(dir_tables_step4, paste0(safe_name(name), ".csv"))

save_plot_pdf <- function(p, name, w=10, h=8) {
  out_pdf <- plot_pdf_path(name)
  device_fun <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(filename = out_pdf, plot = p, width = w, height = h, device = device_fun, limitsize = FALSE)
  log_msg("Saved plot: ", out_pdf)
  invisible(out_pdf)
}

# ----------------------------
# Start logs
# ----------------------------
log_msg("PRISM R step starting")
log_msg("output_dir: ", opt$output_dir)
log_msg("work_dir: ", opt$work_dir)
log_msg("artifacts_dir: ", opt$artifacts_dir)

# Optional: show python (useful for reticulate sanity)
try({ py_config() }, silent = TRUE)

# ----------------------------
# Load Seurat object
# ----------------------------
seurat_rds <- opt$seurat_rds %||% work_path("sce1_output.rds")
require_file(seurat_rds, "Seurat RDS (--seurat-rds or <work-dir>/sce1_output.rds)")

log_msg("Loading Seurat object: ", seurat_rds)
sce1 <- readRDS(seurat_rds)
if (!inherits(sce1, "Seurat")) stop("Loaded object is not a Seurat object: ", seurat_rds)
DefaultAssay(sce1) <- "RNA"

# ----------------------------
# Read & normalize label tables
# ----------------------------
normalize_labels <- function(df) {
  df %>%
    rename(
      barcode = any_of(c("barcode", "Barcode")), # tolerate casing
      Nover   = any_of(c("Nover", "Annotation", "celltype", "final_label", "clonotype"))
    ) %>%
    mutate(
      barcode = as.character(barcode),
      Nover   = as.character(Nover)
    ) %>%
    select(barcode, Nover)
}

# Required inputs (as in your original script)
lab_tme   <- read_csv(art_path("TME.noverlabel.csv"),   show_col_types = FALSE) %>% normalize_labels()
lab_pc    <- read_csv(art_path("PC.noverlabel.csv"),    show_col_types = FALSE) %>% normalize_labels()
lab_tcell <- read_csv(art_path("Tcell.noverlabel.csv"), show_col_types = FALSE) %>% normalize_labels()
lab_bcell <- read_csv(art_path("Bcell.noverlabel.csv"), show_col_types = FALSE) %>% normalize_labels()
lab_mono  <- read_csv(art_path("Mono.noverlabel.csv"),  show_col_types = FALSE) %>% normalize_labels()
lab_nk    <- read_csv(art_path("NKcell.noverlabel.csv"),show_col_types = FALSE) %>% normalize_labels()

# Priority lookup: PC > T > B > Mono > NK (matching your intended order)
lookup <- bind_rows(
  mutate(lab_pc,    .src = "Plasmacell"),
  mutate(lab_tcell, .src = "Tcell"),
  mutate(lab_bcell, .src = "Bcell"),
  mutate(lab_mono,  .src = "Mono"),
  mutate(lab_nk,    .src = "NKcell")
) %>%
  arrange(factor(.src, levels = c("Plasmacell", "Tcell", "Bcell", "Mono", "NKcell"))) %>%
  group_by(barcode) %>%
  summarise(Nover_new = first(na.omit(Nover)), .groups = "drop")

# Update TME labels, then bind PC labels
final_tbl <- lab_tme %>%
  left_join(lookup, by = "barcode") %>%
  mutate(Nover = coalesce(Nover_new, Nover)) %>%
  select(barcode, Nover) %>%
  bind_rows(lab_pc) %>%
  distinct(barcode, .keep_all = TRUE)

# Add to Seurat meta.data robustly (by barcode / cellname)
final_map <- final_tbl$Nover
names(final_map) <- final_tbl$barcode

sce1$Nover <- unname(final_map[colnames(sce1)]) # safe align; yields NA if missing

# ----------------------------
# Plot: UMAP by Nover
# ----------------------------
if ("Nover" %in% colnames(sce1@meta.data)) {
  p_umap <- DimPlot_scCustom(
    sce1,
    pt.size = 1,
    reduction = "UMAP",
    group.by = "Nover",
    label = TRUE
  )
  save_plot_pdf(p_umap, "umap_cellchat_cells", w = 10, h = 8)
} else {
  log_msg("Skipping UMAP: 'Nover' not found in meta.data.")
}

# ----------------------------
# CellChat per-sample
# ----------------------------
group_col  <- opt$`group-col`
sample_col <- opt$`sample-col`
species    <- tolower(opt$species)
expr_prop  <- max(0.0, min(1.0, opt$`expr-prop`))
min_cells  <- opt$`min-cells`
top_k_pathways <- opt$`top-k-pathways`

if (!group_col %in% colnames(sce1@meta.data)) {
  stop(sprintf("group_col '%s' not found in meta.data. Available: %s",
               group_col, paste(colnames(sce1@meta.data), collapse = ", ")))
}
if (!sample_col %in% colnames(sce1@meta.data)) {
  stop(sprintf("sample_col '%s' not found in meta.data. Available: %s",
               sample_col, paste(colnames(sce1@meta.data), collapse = ", ")))
}

.try_compute <- function(cc) {
  ok <- TRUE
  cc2 <- tryCatch({
    computeCommunProb(cc, raw.use = TRUE, type = "truncatedMean", trim = 0.1)
  }, error = function(e) { ok <<- FALSE; e })
  if (ok) return(cc2)

  ok <- TRUE
  cc2 <- tryCatch({
    computeCommunProb(cc, raw.use = TRUE, type = "triMean")
  }, error = function(e) { ok <<- FALSE; e })
  if (ok) return(cc2)

  ok <- TRUE
  cc2 <- tryCatch({
    computeCommunProb(cc, raw.use = FALSE, type = "truncatedMean", trim = 0.1)
  }, error = function(e) { ok <<- FALSE; e })
  if (ok) return(cc2)

  stop("computeCommunProb failed under multiple settings; data may have no valid LR after filtering.")
}

run_cellchat_for_subset <- function(seu_sub, group_col, species, expr_prop = 0.05, min_cells = 10) {
  counts <- tryCatch(
    GetAssayData(seu_sub, slot = "counts"),
    error = function(e) GetAssayData(seu_sub, slot = "data")
  )
  if (!inherits(counts, "dgCMatrix")) counts <- as(as.matrix(counts), "dgCMatrix")

  meta <- seu_sub@meta.data
  meta$cell <- colnames(seu_sub)
  meta$group <- as.character(meta[[group_col]])
  rownames(meta) <- meta$cell
  meta <- meta[colnames(counts), c("cell", "group"), drop = FALSE]

  data.cellchat <- if (species == "mouse") CellChatDB.mouse else CellChatDB.human

  cellchat <- createCellChat(object = counts, meta = meta, group.by = "group")
  cellchat@DB <- data.cellchat
  cellchat <- subsetData(cellchat)

  cellchat <- identifyOverExpressedGenes(cellchat, thresh.pc = expr_prop)
  cellchat <- identifyOverExpressedInteractions(cellchat)

  # If OE-filter removes everything, retry at thresh.pc=0
  if (!is.null(cellchat@LR$LRsig) && nrow(cellchat@LR$LRsig) == 0) {
    message("No LR after OE-filter; retrying with thresh.pc=0")
    cellchat <- identifyOverExpressedGenes(cellchat, thresh.pc = 0)
    cellchat <- identifyOverExpressedInteractions(cellchat)
  }

  cellchat <- .try_compute(cellchat)
  cellchat <- filterCommunication(cellchat, min.cells = min_cells)

  df.net <- subsetCommunication(cellchat)

  # Standardize prob column
  if (!"prob" %in% colnames(df.net)) {
    if ("prob_weight" %in% colnames(df.net)) df.net$prob <- df.net$prob_weight
    if (!"prob" %in% colnames(df.net) && "weight" %in% colnames(df.net)) df.net$prob <- df.net$weight
  }

  df.net
}

all_samples <- sort(unique(as.character(sce1@meta.data[[sample_col]])))
log_msg(sprintf("Found %d samples via %s", length(all_samples), sample_col))

results_list <- list()

for (sid in all_samples) {
  log_msg(">>> Processing sample: ", sid)
  seu_sub <- subset(sce1, subset = !!as.name(sample_col) == sid)

  tab_groups <- table(seu_sub@meta.data[[group_col]])
  if (length(tab_groups) < 2) {
    log_msg("Skipping ", sid, ": <2 groups in '", group_col, "'")
    next
  }

  df.net <- tryCatch(
    run_cellchat_for_subset(seu_sub, group_col, species, expr_prop, min_cells),
    error = function(e) {
      log_msg("CellChat failed for ", sid, ": ", e$message)
      NULL
    }
  )

  if (is.null(df.net) || nrow(df.net) == 0) {
    log_msg("No interactions for ", sid, " after filtering.")
    next
  }

  df.net$sample_id <- sid
  results_list[[sid]] <- df.net

  write_csv(df.net, table_csv_path(sprintf("cellchat_pairs__%s", sid)))
  log_msg("Saved table: ", table_csv_path(sprintf("cellchat_pairs__%s", sid)))
}

if (length(results_list) == 0) stop("No samples produced interactions. Check thresholds, group_col, or data sparsity.")

all_pairs <- bind_rows(results_list)

# ----------------------------
# Plasma-involving filtering & ranking
# ----------------------------
plasma_patterns <- c("PlasmaCells")
plasma_regex <- paste0("(^|[^A-Za-z])(", paste(plasma_patterns, collapse="|"), ")([^A-Za-z]|$)")

all_pairs <- all_pairs %>%
  mutate(
    is_plasma_source = str_detect(source, plasma_regex),
    is_plasma_target = str_detect(target, plasma_regex)
  )

plasma_pairs <- all_pairs %>%
  filter(is_plasma_source | is_plasma_target) %>%
  mutate(
    direction = case_when(
      is_plasma_source & !is_plasma_target ~ "Plasma->Immune",
      !is_plasma_source & is_plasma_target ~ "Immune->Plasma",
      TRUE ~ "Plasma<->Plasma"
    ),
    partner_cell = if_else(is_plasma_source, target, source)
  )

if (!"pathway_name" %in% colnames(plasma_pairs)) {
  plasma_pairs <- plasma_pairs %>%
    mutate(pathway_name = coalesce(.data$pathway_name, .data$interaction_name_2))
}

ranked_summary <- plasma_pairs %>%
  group_by(sample_id, pathway_name) %>%
  summarise(
    max_prob = max(prob, na.rm = TRUE),
    mean_prob = mean(prob, na.rm = TRUE),
    n_pairs = dplyr::n(),
    partners = paste(sort(unique(partner_cell)), collapse = "; "),
    directions = paste(sort(unique(direction)), collapse = "; "),
    .groups = "drop"
  ) %>%
  arrange(sample_id, desc(max_prob)) %>%
  group_by(sample_id) %>%
  mutate(rank = dplyr::row_number()) %>%
  ungroup() %>%
  filter(rank <= top_k_pathways)

top_keys <- ranked_summary %>% distinct(sample_id, pathway_name)

details_top <- plasma_pairs %>%
  inner_join(top_keys, by = c("sample_id", "pathway_name")) %>%
  select(sample_id, pathway_name, direction, source, target,
         partner_cell, ligand, receptor, interaction_name_2, prob) %>%
  arrange(sample_id, desc(prob))

write_csv(ranked_summary, table_csv_path("plasma_pathways_ranked_summary"))
write_csv(details_top,   table_csv_path("plasma_pathways_top_details"))
write_csv(plasma_pairs,  table_csv_path("plasma_pathways_all_pairs"))
log_msg("Saved tables: ranked_summary / details_top / plasma_pairs to ", dir_tables_step4)

# ----------------------------
# Dotplots (per sample) — saved via art_path()
# ----------------------------
min_prob_show <- opt$`min-prob-show`
point_alpha   <- 0.95
size_range    <- c(1.8, 8.5)

# Partner filter keywords: use observed labels from your label tables (as you intended)
partner_filter_keywords <- c(
  "PlasmaCells",
  unique(lab_tcell$Nover), unique(lab_bcell$Nover), unique(lab_mono$Nover), unique(lab_nk$Nover)
)
partner_filter_exclude <- NULL
append_present_keywords_only <- TRUE

# Matching helpers (robust underscore/space/dash variance)
normalize_for_match <- function(x) {
  x <- as.character(x)
  x <- gsub("[\u2013\u2014\u2212]", "-", x)   # en/em dash, unicode minus -> '-'
  x <- gsub("[_ ]+", " ", x)                 # underscores/spaces -> single space
  x <- tolower(trimws(x))
  x
}
compact_key <- function(x) gsub(" ", "", normalize_for_match(x), fixed = TRUE)
normalize_keywords <- function(x) {
  x <- unique(trimws(as.character(x)))
  x[!is.na(x) & nzchar(x)]
}

lr_with_pathway <- function(pathway, lr) sprintf("[%s] %s", pathway, lr)

plot_plasma_dotplot_for_sample <- function(sid, df_sum, df_det) {
  top_paths <- df_sum %>%
    filter(sample_id == sid) %>%
    arrange(desc(max_prob)) %>%
    slice_head(n = top_k_pathways) %>%
    pull(pathway_name) %>%
    unique()

  pdat <- df_det %>%
    filter(sample_id == sid, pathway_name %in% top_paths) %>%
    filter(!is.na(prob), prob >= min_prob_show) %>%
    mutate(
      partner_cell = as.character(partner_cell),
      lr_label  = lr_with_pathway(pathway_name, interaction_name_2),
      direction = factor(direction, levels = c("Plasma->Immune","Immune->Plasma","Plasma<->Plasma")),
      partner_key  = compact_key(partner_cell)
    )

  if (!nrow(pdat)) return(NULL)

  kw_inc <- normalize_keywords(partner_filter_keywords)
  kw_exc <- normalize_keywords(partner_filter_exclude)
  kw_inc_key <- compact_key(kw_inc)
  kw_exc_key <- compact_key(kw_exc)

  if (length(kw_inc_key)) {
    keep <- pdat$partner_key %in% kw_inc_key
    pdat <- pdat[keep, , drop = FALSE]
  }
  if (nrow(pdat) && length(kw_exc_key)) {
    drop <- pdat$partner_key %in% kw_exc_key
    pdat <- pdat[!drop, , drop = FALSE]
  }
  if (!nrow(pdat)) return(NULL)

  immune_order <- pdat %>%
    count(partner_cell, wt = prob) %>%
    arrange(desc(n)) %>%
    pull(partner_cell)

  immune_order_full <- unique(immune_order)
  if (append_present_keywords_only && length(kw_inc_key)) {
    present_keys <- intersect(unique(pdat$partner_key), kw_inc_key)
    if (length(present_keys)) {
      key_to_label <- pdat %>%
        distinct(partner_key, partner_cell) %>%
        filter(partner_key %in% present_keys) %>%
        arrange(match(partner_key, present_keys)) %>%
        pull(partner_cell)
      immune_order_full <- unique(c(immune_order_full, key_to_label))
    }
  }

  lr_order <- pdat %>%
    group_by(pathway_name, lr_label) %>%
    summarise(max_prob = max(prob, na.rm = TRUE), .groups = "drop") %>%
    arrange(desc(max_prob), lr_label) %>%
    pull(lr_label)

  pdat <- pdat %>%
    mutate(
      partner_cell = factor(partner_cell, levels = immune_order_full),
      lr_label     = factor(lr_label, levels = rev(unique(lr_order)))
    )

  g <- ggplot(pdat, aes(x = partner_cell, y = lr_label)) +
    geom_point(aes(size = prob, color = direction), alpha = point_alpha) +
    scale_size(range = size_range, name = "Interaction probability") +
    labs(
      x = "Immune partner cell type",
      y = "Ligand–Receptor (grouped by pathway)",
      title = sprintf("Plasma-involving top pathways • Sample: %s", sid),
      subtitle = "Dot size: CellChat probability (prob). Color: direction."
    ) +
    theme_minimal(base_size = 11) +
    theme(
      panel.grid.major.x = element_line(linewidth = 0.2),
      panel.grid.major.y = element_line(linewidth = 0.2),
      axis.text.x = element_text(angle = 90, vjust = 0.5, hjust = 1),
      plot.title = element_text(face = "bold"),
      plot.margin = margin(5.5, 20, 5.5, 5.5, "pt")
    )

  g
}

samples <- sort(unique(details_top$sample_id))
for (sid in samples) {
  gp <- plot_plasma_dotplot_for_sample(sid, ranked_summary, details_top)
  if (is.null(gp)) {
    log_msg("Dotplot skipped (no rows after filtering) for sample: ", sid)
    next
  }
  out_path <- dotplot_pdf_path(sprintf("plasma_top_pathways_dotplot__%s", sid))
  ggsave(out_path, gp, width = 8.5, height = 11, limitsize = FALSE)
  log_msg("Saved dotplot: ", out_path)
}

log_msg("PRISM R step 4 finished successfully.")

#!/usr/bin/env Rscript

# ============================
# PRISM standard CLI header (R) — PATCHED FULL SCRIPT
# ============================

suppressPackageStartupMessages({
  library(optparse)
  library(reticulate)
  library(Seurat)
  library(ggplot2)
  library(scCustomize)
  library(tibble)
  library(pheatmap)
  library(dplyr)
  library(scales)
})


set.seed(123)

# ----------------------------
# CLI options
# ----------------------------
option_list <- list(
  make_option(c("--h5ad"), type="character", default=NA_character_,
              help="Path to input .h5ad (not used in this step unless you enable conversion)"),
  make_option(c("--metadata"), type="character", default=NA_character_,
              help="Path to metadata CSV (optional for this step unless you need it)"),
  make_option(c("--output-dir"), type="character", default=".",
              help="Task output directory (root for logs/work/artifacts)"),
  make_option(c("--work-dir"), type="character", default=NA_character_,
              help="Working directory for intermediates (default: <output-dir>/work)"),
  make_option(c("--artifacts-dir"), type="character", default=NA_character_,
              help="Directory for final artifacts (default: <output-dir>/artifacts)"),
  make_option(c("--task-id"), type="integer", default=NA_integer_,
              help="Task ID (for logging/UI)"),
  make_option(c("--step-id"), type="character", default=NA_character_,
              help="Step ID like 1, 2.1, 3.2, 4.1 (for logging/UI)"),

  # Inputs used in THIS script
  make_option(c("--seurat-rds"), type="character", default=NA_character_,
              help="Path to input Seurat .rds (default: <work-dir>/sce1_plasmacell.rds)")
)  # <-- THIS was missing

opt <- parse_args(OptionParser(option_list = option_list))

# ----------------------------
# Helpers: robust option
# ----------------------------
is_unset <- function(x) is.null(x) || length(x) == 0 || all(is.na(x)) || !nzchar(as.character(x)[1])

`%||%` <- function(a, b) if (!is_unset(a)) a else b

# ---- Logging helpers ----
log_msg <- function(...) {
  ts <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  cat(sprintf("[%s][task=%s][step=%s] ", ts, opt$task_id, opt$step_id),
      paste0(..., collapse=""), "\n")
}


# ---- Resolve defaults (ROBUST) ----
opt$output_dir    <- opt$output_dir %||% "."
opt$work_dir      <- opt$work_dir %||% file.path(opt$output_dir, "work")
opt$artifacts_dir <- opt$artifacts_dir %||% file.path(opt$output_dir, "artifacts")

dir.create(opt$output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$work_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$artifacts_dir, recursive = TRUE, showWarnings = FALSE)

work_path <- function(...) file.path(opt$work_dir, ...)
art_path  <- function(...) file.path(opt$artifacts_dir, ...)


# ---- File check helper ----
require_file <- function(path, label) {
  if (is_unset(path)) stop(sprintf("Missing required input: %s", label))
  if (!file.exists(path)) stop(sprintf("File not found for %s: %s", label, path))
}

# ---- Plot path helper ----
plots_dir <- file.path(opt$artifacts_dir, "plots_step2")
dir.create(plots_dir, recursive = TRUE, showWarnings = FALSE)

plot_pdf_path <- function(name) {
  safe <- gsub("[[:space:]]+", "_", name)
  safe <- gsub("[^A-Za-z0-9_\\-\\.]", "", safe)
  file.path(plots_dir, paste0(safe, ".pdf"))
}

# ---- Safe ggsave wrapper ----
save_plot_pdf <- function(p, name, w=10, h=8) {
  out_pdf <- plot_pdf_path(name)
  ggsave(filename = out_pdf, plot = p, width = w, height = h, device = cairo_pdf)
  log_msg("Saved plot: ", out_pdf)
  invisible(out_pdf)
}

# ----------------------------
# Start logs
# ----------------------------
log_msg("PRISM R step starting")
log_msg("h5ad: ", opt$h5ad)
log_msg("metadata: ", opt$metadata)
log_msg("output_dir: ", opt$output_dir)
log_msg("work_dir: ", opt$work_dir)
log_msg("artifacts_dir: ", opt$artifacts_dir)

# ----------------------------
# Inputs
# ----------------------------
seurat_rds <- opt$seurat_rds %||% work_path("sce1_plasmacell.rds")
require_file(seurat_rds, "Seurat RDS (--seurat-rds or <work-dir>/sce1_plasmacell.rds)")

log_msg("Loading Seurat object: ", seurat_rds)
sce1_plasma <- readRDS(seurat_rds)

if (!inherits(sce1_plasma, "Seurat")) {
  stop("Loaded object is not a Seurat object: ", seurat_rds)
}

# Ensure RNA assay active when doing standard workflow
if ("RNA" %in% Assays(sce1_plasma)) {
  DefaultAssay(sce1_plasma) <- "RNA"
}

# ----------------------------
# Standard analysis workflow
# ----------------------------
log_msg("NormalizeData / FindVariableFeatures")
sce1_plasma <- NormalizeData(sce1_plasma, verbose = FALSE)
sce1_plasma <- FindVariableFeatures(sce1_plasma, verbose = FALSE)

# Exclude immunoglobulin genes from variable features
ig_genes <- grep("^(IGK|IGH|IGL)", rownames(sce1_plasma), value = TRUE)
if (length(ig_genes) > 0) {
  current_vf <- VariableFeatures(sce1_plasma)
  filtered_vf <- setdiff(current_vf, ig_genes)
  VariableFeatures(sce1_plasma) <- filtered_vf
  log_msg("Filtered IG genes from variable features: removed ", length(setdiff(current_vf, filtered_vf)),
          " / remaining ", length(filtered_vf))
} else {
  log_msg("No IG genes matched for filtering (pattern ^(IGK|IGH|IGL)).")
}

log_msg("ScaleData / RunPCA")
sce1_plasma <- ScaleData(sce1_plasma, features = VariableFeatures(sce1_plasma), verbose = FALSE)
sce1_plasma <- RunPCA(sce1_plasma, features = VariableFeatures(sce1_plasma), verbose = FALSE)

log_msg("FindNeighbors / FindClusters / RunUMAP")
sce1_plasma <- FindNeighbors(sce1_plasma, dims = 1:15, reduction = "pca", verbose = FALSE)
sce1_plasma <- FindClusters(sce1_plasma, resolution = 1, cluster.name = "seurat_clusters", verbose = FALSE)
sce1_plasma <- RunUMAP(sce1_plasma, dims = 1:15, reduction = "pca", reduction.name = "UMAP", verbose = FALSE)


# ----------------------------
# Plots
# ----------------------------
# 1) UMAP: seurat_clusters
p1 <- DimPlot_scCustom(
  sce1_plasma,
  pt.size = 1,
  reduction = "UMAP",
  group.by = "seurat_clusters",
  label = TRUE
)
save_plot_pdf(p1, "umap_seurat_clusters_plasma", w=10, h=8)

# 2) UMAP: orig.ident (if present)
if ("orig.ident" %in% colnames(sce1_plasma@meta.data)) {
  p2 <- DimPlot_scCustom(
    sce1_plasma,
    pt.size = 1,
    reduction = "UMAP",
    group.by = "orig.ident",
    label = TRUE
  )
  save_plot_pdf(p2, "umap_orig_ident_plasma", w=10, h=8)
} else {
  log_msg("Skipping orig.ident UMAP: orig.ident not found in meta.data.")
}

# 3) UMAP: cytogenetics (if present)
if ("cytogenetics" %in% colnames(sce1_plasma@meta.data)) {
  p3 <- DimPlot_scCustom(
    sce1_plasma,
    pt.size = 1,
    reduction = "UMAP",
    group.by = "cytogenetics",
    label = TRUE
  )
  save_plot_pdf(p3, "umap_cytogenetics_plasma", w=10, h=8)
} else {
  log_msg("Skipping cytogenetics UMAP: cytogenetics not found in meta.data.")
}

# ----------------------------
# Barplot: plasma cell counts per orig.ident (with consistent colors)
# ----------------------------
if ("orig.ident" %in% colnames(sce1_plasma@meta.data)) {
  log_msg("Building barplot counts per orig.ident")

  # Make orig.ident the active identity for consistent mapping
  Idents(sce1_plasma) <- "orig.ident"
  id_levels <- levels(Idents(sce1_plasma))

  # Use a deterministic palette from ggplot2 defaults:
  # Extract the discrete scale mapping by building a small plot
  tmp_plot <- DimPlot_scCustom(sce1_plasma, reduction = "UMAP", group.by = "orig.ident")
  gb <- ggplot_build(tmp_plot)

  # gb$data[[1]] contains points; gb$plot$scales has the mapping but can be tricky.
  # Easiest robust approach: build a named palette by sampling the scale via hue_pal.
  pal <- scales::hue_pal()(length(id_levels))
  names(pal) <- id_levels

  counts_df <- as.data.frame(table(sce1_plasma@meta.data$orig.ident))
  colnames(counts_df) <- c("orig.ident", "Freq")
  counts_df <- counts_df[order(-counts_df$Freq), ]
  counts_df$Color <- pal[counts_df$orig.ident]

  pdf_file <- plot_pdf_path("quality_control_plasma_counts")
  grDevices::pdf(pdf_file, width = 10, height = 8)
  on.exit(grDevices::dev.off(), add = TRUE)

  op <- par(no.readonly = TRUE)
  on.exit(par(op), add = TRUE)
  par(mar = c(10, 6, 4, 2))

  barplot(
    height = counts_df$Freq,
    names.arg = counts_df$orig.ident,
    col = counts_df$Color,
    ylab = "Number of plasma cells",
    las = 2,
    border = NA,
    ylim = range(pretty(c(0, counts_df$Freq)))
  )
  dev.off()
  log_msg("Saved plot: ", pdf_file)
} else {
  log_msg("Skipping barplot: orig.ident not found in meta.data.")
}

# ----------------------------
# Fixed marker gene list (unchanged) + Violin plot
# ----------------------------
gene_list_fixed <- c(
  "CCND1", "CCND2", "CCND3", "MYC", "MAF", "MAFB",
  "FGFR3", "NSD2", "WHSC1", "ITGB7", "CD38", "SDC1",
  "CD27", "CD79A"
)

genes_present <- intersect(gene_list_fixed, rownames(sce1_plasma))
genes_missing <- setdiff(gene_list_fixed, genes_present)

if (length(genes_missing) > 0) {
  log_msg("Fixed gene list: missing in object (skipped): ", paste(genes_missing, collapse = ", "))
}

if (length(genes_present) == 0) {
  log_msg("Skipping fixed gene violin plot: none of the fixed genes are present in rownames(sce1_plasma).")
} else {
  log_msg("Making Stacked_VlnPlot for fixed genes: ", paste(genes_present, collapse = ", "))
  vp <- Stacked_VlnPlot(
    seurat_object = sce1_plasma,
    features = genes_present,
    x_lab_rotate = 90
  )
  save_plot_pdf(vp, "violin_fixed_marker_genes_plasma", w = 14, h = 10)
}

# ----------------------------
# Read signature CSV (fixed name in work dir): plasmacellsignature.csv
# ----------------------------
table_path <- function(file, artifacts_dir = opt$artifacts_dir) {
  # file can be "plasmacellsignature.csv" or "/plasmacellsignature.csv"
  file <- sub("^/+", "", file)
  file.path(artifacts_dir, "tables", file)
}

# Usage
sig_csv <- table_path("plasmacellsignature.csv")
log_msg("Loading signature CSV: ", sig_csv)
signature <- read.csv(sig_csv, stringsAsFactors = FALSE, check.names = FALSE)

# If it has an index-like first column named X, set rownames and drop it
if ("X" %in% colnames(signature)) {
  rownames(signature) <- signature$X
  signature$X <- NULL
}
sce1_plasma@meta.data<-cbind(sce1_plasma@meta.data,signature)

# ----------------------------
# Heatmap aggregated by orig.ident using meta.data columns with "GEP" in the name
# ----------------------------
if ("orig.ident" %in% colnames(sce1_plasma@meta.data)) {
  meta <- sce1_plasma@meta.data

  # 1) candidate columns = anything with "GEP" in the column name
  candidate_cols <- grep("GEP", colnames(meta), value = TRUE, ignore.case = TRUE)

  if (length(candidate_cols) == 0) {
    log_msg("Skipping meta.data heatmap: no meta.data columns contain 'GEP'.")
  } else {
    # 2) keep only numeric columns (pheatmap requires numeric matrix)
    numeric_cols <- candidate_cols[vapply(meta[, candidate_cols, drop = FALSE], is.numeric, logical(1))]

    if (length(numeric_cols) == 0) {
      log_msg("Skipping meta.data heatmap: 'GEP' columns found but none are numeric.")
    } else {
      log_msg("Heatmap: using ", length(numeric_cols), " numeric 'GEP' meta.data columns (rows).")

      avg_df <- meta %>%
        dplyr::group_by(orig.ident) %>%
        dplyr::summarise(
          dplyr::across(dplyr::all_of(numeric_cols), ~ mean(.x, na.rm = TRUE)),
          .groups = "drop"
        ) %>%
        tibble::column_to_rownames("orig.ident")

      avg_mat   <- as.matrix(avg_df)
      avg_mat_t <- t(avg_mat)  # rows = features (GEP cols), cols = orig.ident

      out_pdf <- plot_pdf_path("meta_GEP_heatmap_by_orig_ident")

      pheatmap::pheatmap(
        mat = avg_mat_t,
        scale = "row",
        border_color = NA,
        cluster_rows = FALSE,
        clustering_distance_cols = "euclidean",
        clustering_method = "complete",
        color = colorRampPalette(c("white", "white", "#2c3991"))(100),
        fontsize_row = 8,
        fontsize_col = 8,
        show_rownames = TRUE,
        show_colnames = TRUE,
        filename = out_pdf,
        width = 15,
        height = 10
      )

      log_msg("Saved plot: ", out_pdf)
    }
  }
} else {
  log_msg("Skipping heatmap: orig.ident not found in meta.data.")
}

label<-sce1_plasma@meta.data
label$barcode<-rownames(label)
label<-label[,c('barcode','seurat_clusters')]
label$seurat_clusters <- 'PlasmaCells'
write.csv(label,file=art_path('PC.noverlabel.csv'))

# Save updated object for downstream steps
out_rds <- work_path("sce1_plasmacell_processed.rds")
saveRDS(sce1_plasma, out_rds)
log_msg("Saved processed Seurat object: ", out_rds)

log_msg("PRISM R step 2.2 finished successfully.")

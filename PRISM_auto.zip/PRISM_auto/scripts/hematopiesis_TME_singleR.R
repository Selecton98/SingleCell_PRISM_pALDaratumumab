#!/usr/bin/env Rscript

# ============================
# PRISM standard CLI header (R) — PATCHED FULL SCRIPT
# ============================
# Set these *before* library(reticulate) or library(sceasy)
Sys.setenv(RETICULATE_PYTHON = "/lab-share/Cardio-Pu-e2/Public/ch257181_sunny/miniconda3/envs/carlin/bin/python")
options(reticulate.conda_binary = "/lab-share/Cardio-Pu-e2/Public/ch257181_sunny/miniconda3/bin/conda")

library(reticulate)
py_config()  # should now show your conda 'jupyter' Python


suppressPackageStartupMessages({
  library(optparse)
  library(Seurat)
  library(patchwork)
  library(ggplot2)
  library(scCustomize)

  # SingleR + reference
  library(SingleR)
  library(celldex)
  library(SingleCellExperiment)

  # Data munging / plotting helpers
  library(dplyr)
  library(reshape2)
  library(dendextend)
  library(ggdendro)
  library(reticulate)
  library(sceasy)
})

set.seed(123)

# ----------------------------
# CLI options
# ----------------------------
option_list <- list(
  make_option(c("--h5ad"), type="character", default=NA_character_,
              help="Path to input .h5ad (not used in this step unless you enable conversion)"),
  make_option(c("--metadata"), type="character", default=NA_character_,
              help="Path to metadata CSV (optional for this step unless you need it)"),
  make_option(c("--output-dir"), type="character", default=".",
              help="Task output directory (root for logs/work/artifacts)"),
  make_option(c("--work-dir"), type="character", default=NA_character_,
              help="Working directory for intermediates (default: <output-dir>/work)"),
  make_option(c("--artifacts-dir"), type="character", default=NA_character_,
              help="Directory for final artifacts (default: <output-dir>/artifacts)"),
  make_option(c("--task-id"), type="integer", default=NA_integer_,
              help="Task ID (for logging/UI)"),
  make_option(c("--step-id"), type="character", default=NA_character_,
              help="Step ID like 1, 2.1, 3.2, 4.1 (for logging/UI)"),

  # Inputs used in THIS script
  make_option(c("--seurat-rds"), type="character", default=NA_character_,
              help="Path to input Seurat .rds (default: <work-dir>/sce1_nonplasmacell.rds)")
)

opt <- parse_args(OptionParser(option_list = option_list))

# ----------------------------
# Helpers: robust option
# ----------------------------
is_unset <- function(x) is.null(x) || length(x) == 0 || all(is.na(x)) || !nzchar(as.character(x)[1])
`%||%` <- function(a, b) if (!is_unset(a)) a else b

# ---- Logging helpers ----
log_msg <- function(...) {
  ts <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  cat(sprintf("[%s][task=%s][step=%s] ", ts, opt$task_id, opt$step_id),
      paste0(..., collapse=""), "\n")
}

# ---- Resolve defaults (ROBUST) ----
opt$output_dir    <- opt$output_dir %||% "."
opt$work_dir      <- opt$work_dir %||% file.path(opt$output_dir, "work")
opt$artifacts_dir <- opt$artifacts_dir %||% file.path(opt$output_dir, "artifacts")

dir.create(opt$output_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$work_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(opt$artifacts_dir, recursive = TRUE, showWarnings = FALSE)

work_path <- function(...) file.path(opt$work_dir, ...)
art_path  <- function(...) file.path(opt$artifacts_dir, ...)

# ---- File check helper ----
require_file <- function(path, label) {
  if (is_unset(path)) stop(sprintf("Missing required input: %s", label))
  if (!file.exists(path)) stop(sprintf("File not found for %s: %s", label, path))
}

# ---- Plot path helper ----
plots_dir <- file.path(opt$artifacts_dir, "plots_step3")
dir.create(plots_dir, recursive = TRUE, showWarnings = FALSE)

plot_pdf_path <- function(name) {
  safe <- gsub("[[:space:]]+", "_", name)
  safe <- gsub("[^A-Za-z0-9_\\-\\.]", "", safe)
  file.path(plots_dir, paste0(safe, ".pdf"))
}

# ---- Safe ggsave wrapper (cairo if available) ----
save_plot_pdf <- function(p, name, w=10, h=8) {
  out_pdf <- plot_pdf_path(name)
  device_fun <- if (capabilities("cairo")) grDevices::cairo_pdf else grDevices::pdf
  ggsave(filename = out_pdf, plot = p, width = w, height = h, device = device_fun)
  log_msg("Saved plot: ", out_pdf)
  invisible(out_pdf)
}

# ----------------------------
# Start logs
# ----------------------------
log_msg("PRISM R step starting")
log_msg("h5ad: ", opt$h5ad)
log_msg("metadata: ", opt$metadata)
log_msg("output_dir: ", opt$output_dir)
log_msg("work_dir: ", opt$work_dir)
log_msg("artifacts_dir: ", opt$artifacts_dir)

# ----------------------------
# Inputs
# ----------------------------
seurat_rds <- opt$seurat_rds %||% work_path("sce1_nonplasmacell.rds")
require_file(seurat_rds, "Seurat RDS (--seurat-rds or <work-dir>/sce1_nonplasmacell.rds)")

log_msg("Loading Seurat object: ", seurat_rds)
sce1_nonplasma <- readRDS(seurat_rds)
if (!inherits(sce1_nonplasma, "Seurat")) stop("Loaded object is not a Seurat object: ", seurat_rds)

DefaultAssay(sce1_nonplasma) <- "RNA"

# ----------------------------
# Standard analysis workflow
# ----------------------------
log_msg("NormalizeData / FindVariableFeatures")
sce1_nonplasma <- NormalizeData(sce1_nonplasma, verbose = FALSE)
sce1_nonplasma <- FindVariableFeatures(sce1_nonplasma, verbose = FALSE)

log_msg("ScaleData / RunPCA")
sce1_nonplasma <- ScaleData(
  sce1_nonplasma,
  features = VariableFeatures(sce1_nonplasma),
  verbose = FALSE
)
sce1_nonplasma <- RunPCA(
  sce1_nonplasma,
  features = VariableFeatures(sce1_nonplasma),
  verbose = FALSE
)

log_msg("FindNeighbors / FindClusters / RunUMAP")
sce1_nonplasma <- FindNeighbors(sce1_nonplasma, dims = 1:15, reduction = "pca", verbose = FALSE)
sce1_nonplasma <- FindClusters(sce1_nonplasma, resolution = 1, cluster.name = "seurat_clusters", verbose = FALSE)
sce1_nonplasma <- RunUMAP(sce1_nonplasma, dims = 1:15, reduction = "pca", reduction.name = "UMAP", verbose = FALSE)

# ----------------------------
# Plots (early-style)
# ----------------------------
# 1) UMAP: seurat_clusters
p_umap_clusters <- DimPlot_scCustom(
  sce1_nonplasma,
  pt.size = 1,
  reduction = "UMAP",
  group.by = "seurat_clusters",
  label = TRUE
)
save_plot_pdf(p_umap_clusters, "umap_seurat_clusters_nonplasma", w=10, h=8)

# 2) UMAP: orig.ident (if present)
if ("orig.ident" %in% colnames(sce1_nonplasma@meta.data)) {
  p_umap_orig <- DimPlot_scCustom(
    sce1_nonplasma,
    pt.size = 1,
    reduction = "UMAP",
    group.by = "orig.ident",
    label = TRUE
  )
  save_plot_pdf(p_umap_orig, "umap_orig_ident_nonplasma", w=10, h=8)
} else {
  log_msg("Skipping orig.ident UMAP: orig.ident not found in meta.data.")
}

# ----------------------------
# SingleR annotation (FIXED: actually write results into meta.data)
# ----------------------------
log_msg("Running SingleR with NovershternHematopoieticData() reference")
Nover.se <- celldex::NovershternHematopoieticData()

# Convert Seurat -> SCE (avoid sceasy dependency here)
sce_sce <- as.SingleCellExperiment(sce1_nonplasma)

pred <- SingleR(
  test  = sce_sce,
  ref   = Nover.se,
  labels = Nover.se$label.fine
)

# Prefer pruned.labels when available; otherwise labels
nover_labels <- pred$pruned.labels
if (is.null(nover_labels)) nover_labels <- pred$labels

sce1_nonplasma$Nover <- as.character(nover_labels)
log_msg("SingleR done. Nover assigned. Top counts: ")
print(head(sort(table(sce1_nonplasma$Nover), decreasing = TRUE), 10))

# 3) UMAP: Nover
p_umap_nover <- DimPlot_scCustom(
  sce1_nonplasma,
  pt.size = 1,
  reduction = "UMAP",
  group.by = "Nover",
  label = FALSE
)
save_plot_pdf(p_umap_nover, "umap_SingleR_Nover_nonplasma", w=11, h=8)

# ----------------------------
# Color map extraction (so later plots match UMAP colors)
# ----------------------------
# We assume ggplot "group" encodes factor level index (standard for discrete color mapping)
get_dimplot_color_map <- function(p, levels_vec) {
  gb <- ggplot_build(p)
  if (length(gb$data) < 1) return(setNames(rep(NA_character_, length(levels_vec)), levels_vec))

  df <- gb$data[[1]]
  # group -> colour (first seen)
  map_group_col <- df %>%
    dplyr::select(group, colour) %>%
    dplyr::group_by(group) %>%
    dplyr::summarise(colour = dplyr::first(colour), .groups = "drop")

  # group indices should align to factor levels
  group_int <- as.integer(map_group_col$group)
  group_int <- pmax(1L, pmin(length(levels_vec), group_int))
  nm <- levels_vec[group_int]
  out <- setNames(as.character(map_group_col$colour), nm)

  # Ensure every level has a color (fallback to default ggplot hues if missing)
  missing <- setdiff(levels_vec, names(out))
  if (length(missing) > 0) {
    fallback <- scales::hue_pal()(length(levels_vec))
    names(fallback) <- levels_vec
    out <- c(out, fallback[missing])
  }

  out[levels_vec]
}

# Ensure Nover is a factor for consistent ordering
sce1_nonplasma$Nover <- factor(sce1_nonplasma$Nover)
nover_levels <- levels(sce1_nonplasma$Nover)
nover_colors <- get_dimplot_color_map(p_umap_nover, nover_levels)

# ----------------------------
# Cell-type proportions per sample (FIXED: uses sce1_nonplasma, saved to PDF)
# ----------------------------
if (!("orig.ident" %in% colnames(sce1_nonplasma@meta.data))) {
  log_msg("Skipping proportion plots: orig.ident not found in meta.data.")
} else {
  samplecelltype <- sce1_nonplasma@meta.data[, c("orig.ident", "Nover"), drop = FALSE]

  df_summary <- samplecelltype %>%
    group_by(orig.ident, Nover) %>%
    summarise(count = n(), .groups = "drop_last") %>%
    group_by(orig.ident) %>%
    mutate(percentage = count / sum(count) * 100) %>%
    ungroup()

  p_prop <- ggplot(df_summary, aes(x = orig.ident, y = percentage, fill = Nover)) +
    geom_bar(stat = "identity") +
    labs(title = "Percentage of Cell Types (SingleR / Nover)",
         x = "Sample (orig.ident)",
         y = "Percentage") +
    theme_minimal() +
    scale_fill_manual(values = nover_colors) +
    theme(axis.text.x = element_blank(),
          axis.ticks.x = element_blank())

  save_plot_pdf(p_prop, "bar_celltype_percentage_by_orig_ident", w=14, h=6)

    # ----------------------------
    # Dendrogram + stacked proportion plot (ROBUST)
    # ----------------------------
    samplecelltype <- sce1_nonplasma@meta.data[, c("orig.ident", "Nover"), drop = FALSE]
    samplecelltype <- samplecelltype[!is.na(samplecelltype$orig.ident) & !is.na(samplecelltype$Nover), , drop = FALSE]
    
    # Count cells per (Nover x orig.ident)
    tab <- with(samplecelltype, table(Nover, orig.ident))
    samplecelltype_count <- as.data.frame.matrix(tab)
    
    # Need >=2 samples to cluster
    if (ncol(samplecelltype_count) >= 2 && nrow(samplecelltype_count) >= 2) {
    
      distance_matrix <- dist(t(samplecelltype_count))
      hclust_result <- hclust(distance_matrix, method = "ward.D2")
      dendrogram <- as.dendrogram(hclust_result)
    
      cluster_order <- order.dendrogram(dendrogram)
      samplecelltype_count_ordered <- samplecelltype_count[, cluster_order, drop = FALSE]
    
      # Long format for stacked bar
      data_long <- reshape2::melt(
        cbind(celltype = rownames(samplecelltype_count_ordered), samplecelltype_count_ordered),
        id.vars = "celltype",
        variable.name = "orig.ident",
        value.name = "count"
      )
    
      dendrogram_plot <- ggdendro::ggdendrogram(dendrogram, rotate = FALSE) +
        theme_classic() +
        theme(axis.text.x = element_blank(),
              axis.ticks.x = element_blank()) +
        labs(title = "Hierarchical clustering of samples (by Nover composition)")
    
      stacked_bar_plot <- ggplot(data_long, aes(x = orig.ident, y = count, fill = celltype)) +
        geom_bar(position = "fill", stat = "identity") +
        labs(title = "Cell-type composition per sample (ordered)",
             x = "Sample (cluster-ordered)",
             y = "Proportion",
             fill = "Nover") +
        scale_fill_manual(values = nover_colors) +
        theme_classic() +
        theme(axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5))
    
      combined_plot <- dendrogram_plot / stacked_bar_plot
      save_plot_pdf(combined_plot, "dendrogram_and_stacked_bar_celltype_composition", w=16, h=10)
    
    } else {
      log_msg("Skipping dendrogram/stacked plot: need >=2 samples and >=2 cell types after filtering NA.")
    }

}
# ----------------------------
# Lineage collapsing (FIXED: uses sce1_nonplasma; removes duplicate blocks)
# ----------------------------
log_msg("Collapsing Nover -> Nover.lineage")
sce1_nonplasma$Nover.lineage <- as.character(sce1_nonplasma$Nover)

# Myeloid progenitors
sce1_nonplasma$Nover.lineage <- gsub(
  "Colony Forming Unit-Granulocytes|Colony Forming Unit-Monocytes|Common myeloid progenitors|Granulocyte/monocyte progenitors",
  "Myeloid_Progenitors",
  sce1_nonplasma$Nover.lineage
)

# Myeloid dendritic / monocytes
sce1_nonplasma$Nover.lineage <- gsub(
  "Myeloid Dendritic Cells|Plasmacytoid Dendritic Cells|Monocytes",
  "Myeloid_Dendritic",
  sce1_nonplasma$Nover.lineage
)

# Erythroid
sce1_nonplasma$Nover.lineage <- gsub(
  "Erythroid.*",
  "Myeloid_Erythroid",
  sce1_nonplasma$Nover.lineage
)

# Megakaryocytes
sce1_nonplasma$Nover.lineage <- gsub(
  "Megakaryocytes|Colony Forming Unit-Megakaryocytic|Megakaryocyte/erythroid progenitors",
  "Myeloid_Megakaryocyte",
  sce1_nonplasma$Nover.lineage
)

# B cells
sce1_nonplasma$Nover.lineage <- gsub(
  "Early B cells|Pro B cells|Naive B cells|Mature B cells.*",
  "Lymphoid_Bcell",
  sce1_nonplasma$Nover.lineage
)

# T cells (escape + properly)
sce1_nonplasma$Nover.lineage <- gsub(
  "Naive CD4\\+ T cells|Naive CD8\\+ T cells|CD4\\+ Central Memory|CD4\\+ Effector Memory|CD8\\+ Central Memory|CD8\\+ Effector Memory|CD8\\+ Effector Memory RA|NK T cells",
  "Lymphoid_Tcell",
  sce1_nonplasma$Nover.lineage
)

# NK
sce1_nonplasma$Nover.lineage <- gsub(
  "Mature NK cells.*",
  "Lymphoid_NKcell",
  sce1_nonplasma$Nover.lineage
)

# HSPC
sce1_nonplasma$Nover.lineage <- gsub(
  "Hematopoietic stem cells.*",
  "HSPC",
  sce1_nonplasma$Nover.lineage
)

# Granulocytes / basophils / eosinophils
sce1_nonplasma$Nover.lineage <- gsub(
  "Granulocyte.*|Basophils|Eosinophils",
  "Myeloid_Granulocyte",
  sce1_nonplasma$Nover.lineage
)

sce1_nonplasma$Nover.lineage <- factor(sce1_nonplasma$Nover.lineage)

# Plot: lineage UMAP (saved)
p_umap_lineage <- DimPlot_scCustom(
  sce1_nonplasma,
  pt.size = 1,
  reduction = "UMAP",
  group.by = "Nover.lineage",
  label = FALSE
)
save_plot_pdf(p_umap_lineage, "umap_Nover_lineage_nonplasma", w=11, h=8)

# ----------------------------
# Save lineage-specific Seurat objects (RDS)  <-- requested
# ----------------------------
log_msg("Subsetting lineage-specific objects")
sce1_tcell   <- subset(sce1_nonplasma, subset = Nover.lineage %in% "Lymphoid_Tcell")
sce1_bcell   <- subset(sce1_nonplasma, subset = Nover.lineage %in% "Lymphoid_Bcell")
sce1_nkcell  <- subset(sce1_nonplasma, subset = Nover.lineage %in% "Lymphoid_NKcell")
sce1_myeloid <- subset(sce1_nonplasma, subset = Nover.lineage %in% c("Myeloid_Dendritic","Myeloid_Progenitors","HSPC","Myeloid_Granulocyte","Myeloid_Erythroid","Myeloid_Megakaryocyte"))

saveRDS(sce1_tcell,   work_path("sce1_nonplasmacell_lineage_Tcell.rds"))
saveRDS(sce1_bcell,   work_path("sce1_nonplasmacell_lineage_Bcell.rds"))
saveRDS(sce1_nkcell,  work_path("sce1_nonplasmacell_lineage_NKcell.rds"))
saveRDS(sce1_myeloid, work_path("sce1_nonplasmacell_lineage_Myeloid.rds"))

log_msg("Saved lineage-specific RDS:")
log_msg(" - ", work_path("sce1_nonplasmacell_lineage_Tcell.rds"))
log_msg(" - ", work_path("sce1_nonplasmacell_lineage_Bcell.rds"))
log_msg(" - ", work_path("sce1_nonplasmacell_lineage_NKcell.rds"))
log_msg(" - ", work_path("sce1_nonplasmacell_lineage_Myeloid.rds"))

sce1_tcell[["RNA"]] <- as(sce1_tcell[["RNA"]], "Assay")
log_msg("Exporting to h5ad via sceasy: ", work_path("sce1_nonplasmacell_lineage_Tcell.h5ad"))
sceasy::convertFormat(sce1_tcell, from = "seurat", to = "anndata", outFile = work_path("sce1_nonplasmacell_lineage_Tcell.h5ad"))
log_msg("Saved h5ad: ", work_path("sce1_nonplasmacell_lineage_Tcell.h5ad"))

label<-sce1_nonplasma@meta.data
label$barcode<-rownames(label)
label<-label[,c('barcode','Nover')]
write.csv(label,file=art_path('TME.noverlabel.csv'))

# ----------------------------
# Save updated object for downstream steps  <-- requested
# ----------------------------
out_rds <- work_path("sce1_nonplasmacell_processed.rds")
saveRDS(sce1_nonplasma, out_rds)
log_msg("Saved processed Seurat object: ", out_rds)

log_msg("PRISM R step 3.1 finished successfully.")
